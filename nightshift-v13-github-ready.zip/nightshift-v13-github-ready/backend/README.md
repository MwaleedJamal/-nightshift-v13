# NIGHTSHIFT V13 — Garment Intelligence Core

Architecture-first backend for the NIGHTSHIFT retail OS.

## What is implemented

- Multi-store tenancy with memberships and RBAC.
- Email/password auth with Argon2 and JWT.
- Product + variant catalog.
- Append-only inventory ledger.
- Materialized inventory balance projection updated by a database trigger.
- Transactional POS checkout with row locking and idempotency keys.
- Cash/card/Apple Pay/Cash App/Venmo/Zelle payment records.
- Item-level returns with optional restocking.
- Operating expenses.
- Audit log.
- Transactional outbox for durable domain events.
- BullMQ/Redis background jobs.
- Research job pipeline.
- S3-compatible/MinIO pre-signed uploads.
- Reporting endpoints for revenue, COGS, gross profit, net profit, payment mix, inventory value and low stock.
- Prometheus metrics endpoint.
- Swagger/OpenAPI endpoint.
- Docker Compose for Postgres, Redis and MinIO.

## Run

```bash
cp .env.example .env
docker compose up -d
npm install
npm run migrate
npm run seed
npm run dev
```

In a second terminal:

```bash
npm run worker
```

API: http://localhost:8787  
Docs: http://localhost:8787/docs  
Health: http://localhost:8787/health  
Metrics: http://localhost:8787/metrics

Seed login:

- email: `owner@nightshift.local`
- password: `Nightshift123!`

The seed command prints the generated store id. Send it in `x-store-id`.

## Core invariants

1. `inventory_events` is append-only.
2. `inventory_balances` is a projection; application code never directly adjusts quantity.
3. Checkout and returns lock balance/sale rows and execute atomically.
4. Every mutating command writes an audit row.
5. Business events are written to `outbox_events` inside the same transaction as the business mutation.
6. POST commands support an `Idempotency-Key` where duplicate execution would be dangerous.
7. Money is stored in integer cents.
8. Store tenancy is checked on every business route.

See `docs/ARCHITECTURE.md`.


## CounterGrid V12 layer

This edition adds:

- Truth / Control / Intelligence / Experience / Memory planes
- deterministic Decision Engine
- `RECOMMEND / HUMAN_REVIEW / SHADOW / ABSTAIN / BLOCK`
- `UNKNOWN_UNVERIFIED` execution guard
- Action Gateway
- policy-pack versioning
- evidence provenance
- model/config lineage
- decision sessions
- human approvals
- intervention graph
- observed outcomes
- evaluation runs
- execution lineage
- bitemporal policy validity
- offline command envelopes with server revalidation
- backwards outcome → action → evidence → authority → policy → execution flow

See `docs/COUNTERGRID_V12_ARCHITECTURE.md`.


## Vintage Intelligence

NIGHTSHIFT does **not** use ordinary retail condition grading as the core price signal.

The pricing engine separates:
- desirable wear / patina
- structural damage
- rarity
- cultural demand
- provenance
- identity confidence
- exact/near-exact sold and active comparables

Authentic desirable wear can increase suggested price.
Structural damage can reduce it.

Pricing output includes:
- quick-sale price
- target price
- collector ask
- floor
- confidence
- premiums / penalties
- comparable coverage
- explicit reasoning

See `docs/VINTAGE_PRICING_INTELLIGENCE.md`.


## Material History Intelligence

Material history is now a first-class pricing signal.

NIGHTSHIFT tracks more than composition:
- fiber blend
- fabric family
- weave / knit
- fabric weight
- dye / finish
- textile mill / producer
- textile geography
- period of manufacture
- historical significance
- scarcity
- material aging character
- material failure risk

Verified historical material can increase a recommendation.
Unverified material lore cannot.

See `docs/MATERIAL_HISTORY_INTELLIGENCE.md`.


## V13: physical-garment model

V13 makes each physical vintage piece a first-class record.

Added:
- unique per-garment EAN-13 barcode allocator
- unique garment SKU
- intake/inbox state machine
- garment event timeline
- identity version history
- media records
- smart sort scores
- smart collections
- multi-provider comparable-search contracts
- query planning
- comp normalization
- cross-provider deduplication
- robust outlier rejection
- hostile-data flags
- store-specific price-learning calibrator
- simple garment-level POS
- transactional double-sell prevention
- pressure-test script

Run:

```bash
npm run pressure:test
npm test
```

See:
- `docs/NIGHTSHIFT_V13.md`
- `docs/API_FLOW.md`


## Connected Price Lab

V13 now wires the modules together:

1. Create garment → unique SKU + EAN-13 barcode.
2. Store identity/material/wear intelligence.
3. Queue live internet comparable research.
4. Query every configured search provider.
5. Normalize currency.
6. Deduplicate syndicated/repeated listings.
7. Reject extreme price outliers.
8. Flag hostile evidence conditions.
9. Build vintage/material-aware recommendation.
10. Calibrate against this store's realized sales.
11. Recalculate smart-sort scores.
12. Owner chooses final price.
13. Register scans unique garment barcode.
14. Checkout locks garments and marks them sold atomically.

No search provider configured = no fake comps. The research run is marked partial
with a critical `NO_PROVIDERS` flag.
