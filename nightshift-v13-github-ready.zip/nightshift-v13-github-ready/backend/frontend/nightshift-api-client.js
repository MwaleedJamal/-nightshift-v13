export class NightshiftApi {
  constructor({ baseUrl, token, storeId }) {
    this.baseUrl = baseUrl.replace(/\/$/, "");
    this.token = token;
    this.storeId = storeId;
  }

  async request(path, init = {}) {
    const response = await fetch(this.baseUrl + path, {
      ...init,
      headers: {
        "content-type": "application/json",
        "authorization": `Bearer ${this.token}`,
        "x-store-id": this.storeId,
        ...(init.headers || {})
      }
    });
    const body = await response.json();
    if (!response.ok) throw new Error(body.message || body.error || `HTTP ${response.status}`);
    return body;
  }

  inventory() {
    return this.request("/v1/inventory");
  }

  checkout(payload) {
    return this.request("/v1/sales/checkout", {
      method: "POST",
      headers: { "Idempotency-Key": crypto.randomUUID() },
      body: JSON.stringify(payload)
    });
  }

  sales() {
    return this.request("/v1/sales");
  }

  report(from, to) {
    const q = new URLSearchParams({ from, to });
    return this.request(`/v1/reports/summary?${q}`);
  }
}
