create type decision_mode as enum ('RECOMMEND','HUMAN_REVIEW','SHADOW','ABSTAIN','BLOCK');
create type evidence_state as enum ('VERIFIED','PARTIAL','UNKNOWN_UNVERIFIED','CONTRADICTED');
create type intervention_status as enum ('proposed','approved','rejected','executed','failed','cancelled','observed');

create table policy_packs (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references stores(id) on delete cascade,
  policy_key text not null,
  version integer not null,
  status text not null check(status in ('draft','active','retired')),
  rules_json jsonb not null,
  valid_from timestamptz not null,
  valid_to timestamptz,
  system_from timestamptz not null default now(),
  system_to timestamptz,
  created_by uuid references users(id),
  created_at timestamptz not null default now(),
  unique(store_id, policy_key, version)
);
create index policy_packs_active_idx
on policy_packs(store_id,policy_key,status,valid_from desc);

create table evidence_sets (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references stores(id) on delete cascade,
  evidence_type text not null,
  state evidence_state not null,
  confidence numeric(6,5),
  provenance_json jsonb not null default '{}'::jsonb,
  evidence_json jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table model_configs (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references stores(id) on delete cascade,
  model_key text not null,
  version integer not null,
  provider text not null,
  model_name text not null,
  config_json jsonb not null default '{}'::jsonb,
  status text not null check(status in ('draft','active','retired')),
  valid_from timestamptz not null,
  valid_to timestamptz,
  created_at timestamptz not null default now(),
  unique(store_id,model_key,version)
);

create table decision_sessions (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references stores(id) on delete cascade,
  actor_user_id uuid references users(id),
  desired_outcome text not null,
  candidate_action text not null,
  action_payload jsonb not null,
  evidence_set_id uuid references evidence_sets(id),
  policy_pack_id uuid references policy_packs(id),
  model_config_id uuid references model_configs(id),
  mode decision_mode not null,
  rationale_json jsonb not null default '{}'::jsonb,
  state_snapshot_json jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index decision_sessions_store_created_idx on decision_sessions(store_id,created_at desc);

create table approvals (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references stores(id) on delete cascade,
  decision_session_id uuid not null references decision_sessions(id) on delete cascade,
  requested_from_role membership_role not null,
  status text not null check(status in ('pending','approved','rejected','expired')),
  decided_by uuid references users(id),
  decision_note text,
  created_at timestamptz not null default now(),
  decided_at timestamptz
);
create index approvals_pending_idx on approvals(store_id,status,created_at)
where status='pending';

create table interventions (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references stores(id) on delete cascade,
  decision_session_id uuid not null references decision_sessions(id),
  action_type text not null,
  target_type text not null,
  target_id text not null,
  status intervention_status not null default 'proposed',
  chosen_by uuid references users(id),
  chosen_action text,
  executed_at timestamptz,
  execution_reference_type text,
  execution_reference_id text,
  created_at timestamptz not null default now()
);
create index interventions_target_idx on interventions(store_id,target_type,target_id,created_at desc);

create table outcomes (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references stores(id) on delete cascade,
  intervention_id uuid not null references interventions(id) on delete cascade,
  outcome_type text not null,
  observed_json jsonb not null,
  measured_at timestamptz not null,
  created_at timestamptz not null default now()
);
create index outcomes_intervention_idx on outcomes(store_id,intervention_id,measured_at desc);

create table evaluation_runs (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references stores(id) on delete cascade,
  intervention_id uuid not null references interventions(id),
  evaluator_key text not null,
  evaluator_version integer not null,
  score numeric(10,5),
  result_json jsonb not null,
  created_at timestamptz not null default now()
);

create table action_executions (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references stores(id) on delete cascade,
  decision_session_id uuid not null references decision_sessions(id),
  intervention_id uuid references interventions(id),
  action_type text not null,
  idempotency_key text not null,
  mode decision_mode not null,
  policy_pack_id uuid references policy_packs(id),
  evidence_set_id uuid references evidence_sets(id),
  model_config_id uuid references model_configs(id),
  actor_user_id uuid references users(id),
  request_json jsonb not null,
  response_json jsonb,
  status text not null check(status in ('accepted','executed','rejected','failed')),
  created_at timestamptz not null default now(),
  completed_at timestamptz,
  unique(store_id,idempotency_key,action_type)
);

create table store_attributes (
  store_id uuid primary key references stores(id) on delete cascade,
  country_code char(2) not null default 'US',
  region_code text,
  timezone text not null default 'America/Chicago',
  currency char(3) not null default 'USD',
  attributes_json jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

insert into policy_packs
(store_id,policy_key,version,status,rules_json,valid_from,created_by)
select s.id,'retail-core',1,'active',
'{
  "actions": {
    "inventory.adjust": {"minimumRole":"manager","defaultMode":"RECOMMEND"},
    "sale.checkout": {"minimumRole":"cashier","defaultMode":"RECOMMEND"},
    "pricing.applyRecommendation": {"minimumRole":"manager","defaultMode":"HUMAN_REVIEW"},
    "research.autoApply": {"minimumRole":"manager","defaultMode":"BLOCK"},
    "refund.issue": {"minimumRole":"cashier","defaultMode":"HUMAN_REVIEW"}
  },
  "evidence": {
    "UNKNOWN_UNVERIFIED": "ABSTAIN",
    "CONTRADICTED": "BLOCK"
  }
}'::jsonb,
now(), null
from stores s
where not exists (
  select 1 from policy_packs p where p.store_id=s.id and p.policy_key='retail-core'
);
