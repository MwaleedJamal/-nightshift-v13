
create type material_evidence_state as enum (
  'VERIFIED',
  'PARTIAL',
  'UNKNOWN_UNVERIFIED',
  'CONTRADICTED'
);

create table material_profiles (
  variant_id uuid primary key references variants(id) on delete cascade,
  store_id uuid not null references stores(id) on delete cascade,

  fabric_family text,
  weave_or_knit text,
  fabric_weight_gsm numeric(10,2),
  yarn_character text,
  dye_process text,
  finish_process text,
  coating text,

  leather_tanning_process text,
  lining_material text,
  insulation_material text,
  hardware_material text,

  textile_mill text,
  textile_region text,
  textile_country_code char(2),
  garment_country_code char(2),

  estimated_material_era_start integer,
  estimated_material_era_end integer,

  material_identity_confidence numeric(8,5)
    check(material_identity_confidence between 0 and 1),

  material_history_json jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

create table material_components (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references stores(id) on delete cascade,
  variant_id uuid not null references variants(id) on delete cascade,
  fiber text not null,
  percentage numeric(6,3)
    check(percentage is null or (percentage >= 0 and percentage <= 100)),
  component_role text,
  source text,
  evidence_state material_evidence_state not null default 'UNKNOWN_UNVERIFIED',
  confidence numeric(8,5) not null default 0
    check(confidence between 0 and 1),
  created_at timestamptz not null default now()
);
create index material_components_variant_idx
  on material_components(store_id,variant_id);

create table material_history_claims (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references stores(id) on delete cascade,
  variant_id uuid not null references variants(id) on delete cascade,

  claim_key text not null,
  claim_value text not null,
  historical_period text,
  historical_significance numeric(8,5) not null default 0
    check(historical_significance between -1 and 1),
  rarity_score numeric(8,5) not null default 0
    check(rarity_score between -1 and 1),

  evidence_state material_evidence_state not null,
  confidence numeric(8,5) not null
    check(confidence between 0 and 1),

  evidence_set_id uuid references evidence_sets(id),
  provenance_json jsonb not null default '{}'::jsonb,
  notes text,

  created_at timestamptz not null default now()
);
create index material_history_claims_variant_idx
  on material_history_claims(store_id,variant_id,created_at desc);

create table material_age_signals (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references stores(id) on delete cascade,
  variant_id uuid not null references variants(id) on delete cascade,

  signal_key text not null,
  character_score numeric(8,5) not null default 0
    check(character_score between -1 and 1),
  failure_risk numeric(8,5) not null default 0
    check(failure_risk between 0 and 1),

  confidence numeric(8,5) not null
    check(confidence between 0 and 1),
  evidence_state material_evidence_state not null,
  evidence_set_id uuid references evidence_sets(id),
  details_json jsonb not null default '{}'::jsonb,

  created_at timestamptz not null default now()
);
create index material_age_signals_variant_idx
  on material_age_signals(store_id,variant_id,created_at desc);

create table textile_reference_library (
  id uuid primary key default gen_random_uuid(),

  reference_key text not null,
  title text not null,
  source_name text not null,
  source_url text,

  mill_or_producer text,
  fabric_family text,
  weave_or_knit text,
  country_code char(2),
  valid_from_year integer,
  valid_to_year integer,

  reference_json jsonb not null default '{}'::jsonb,
  provenance_json jsonb not null default '{}'::jsonb,
  confidence numeric(8,5) not null
    check(confidence between 0 and 1),

  created_at timestamptz not null default now(),
  unique(reference_key)
);
