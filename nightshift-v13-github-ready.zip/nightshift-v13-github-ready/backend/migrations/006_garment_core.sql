create type garment_status as enum (
  'inbox',
  'identified',
  'researched',
  'priced',
  'ready',
  'reserved',
  'sold',
  'archived'
);

create table store_barcode_namespaces (
  store_id uuid primary key references stores(id) on delete cascade,
  namespace_id integer generated always as identity unique,
  next_sequence bigint not null default 1,
  check(namespace_id between 1 and 999)
);

create table garments (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references stores(id) on delete cascade,

  product_id uuid references products(id),
  variant_id uuid references variants(id),

  garment_sku text not null,
  barcode text not null,
  status garment_status not null default 'inbox',

  display_name text,
  brand text,
  category text,
  subcategory text,
  era_label text,

  acquisition_cost_cents integer not null default 0 check(acquisition_cost_cents >= 0),
  owner_price_cents integer check(owner_price_cents is null or owner_price_cents >= 0),
  price_recommendation_id uuid,

  rack_location text,
  source_name text,
  acquired_at timestamptz,

  fingerprint_json jsonb not null default '{}'::jsonb,
  sortable_features_json jsonb not null default '{}'::jsonb,

  created_by uuid references users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  unique(store_id,garment_sku),
  unique(store_id,barcode)
);

create index garments_store_status_idx
  on garments(store_id,status,updated_at desc);
create index garments_store_brand_idx
  on garments(store_id,brand);
create index garments_store_category_idx
  on garments(store_id,category,subcategory);
create index garments_store_price_idx
  on garments(store_id,owner_price_cents);
create index garments_store_rack_idx
  on garments(store_id,rack_location);

create table garment_media (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references stores(id) on delete cascade,
  garment_id uuid not null references garments(id) on delete cascade,
  storage_key text not null,
  media_type text not null default 'photo',
  position integer not null default 0,
  created_at timestamptz not null default now()
);
create index garment_media_garment_idx on garment_media(store_id,garment_id,position);

create table garment_events (
  id bigserial primary key,
  store_id uuid not null references stores(id) on delete cascade,
  garment_id uuid not null references garments(id) on delete cascade,
  event_type text not null,
  payload_json jsonb not null default '{}'::jsonb,
  actor_user_id uuid references users(id),
  created_at timestamptz not null default now()
);
create index garment_events_garment_idx
  on garment_events(store_id,garment_id,id desc);

create table garment_identity_versions (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references stores(id) on delete cascade,
  garment_id uuid not null references garments(id) on delete cascade,

  version integer not null,
  evidence_set_id uuid references evidence_sets(id),
  confidence numeric(8,5) not null default 0
    check(confidence between 0 and 1),

  brand text,
  model text,
  garment_type text,
  era_start_year integer,
  era_end_year integer,
  era_label text,
  tag_generation text,
  country_of_manufacture text,
  graphic_or_license text,
  construction_json jsonb not null default '{}'::jsonb,
  measurements_json jsonb not null default '{}'::jsonb,

  source text not null,
  created_at timestamptz not null default now(),

  unique(garment_id,version)
);
create index garment_identity_latest_idx
  on garment_identity_versions(store_id,garment_id,version desc);

create table garment_sort_scores (
  garment_id uuid primary key references garments(id) on delete cascade,
  store_id uuid not null references stores(id) on delete cascade,

  collector_score numeric(10,5) not null default 0,
  fast_move_score numeric(10,5) not null default 0,
  rarity_score numeric(10,5) not null default 0,
  margin_score numeric(10,5) not null default 0,
  stale_score numeric(10,5) not null default 0,
  research_priority_score numeric(10,5) not null default 0,

  updated_at timestamptz not null default now()
);

create table smart_collections (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references stores(id) on delete cascade,
  name text not null,
  collection_key text not null,
  rule_json jsonb not null,
  sort_json jsonb not null default '{}'::jsonb,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  unique(store_id,collection_key)
);

insert into smart_collections(store_id,name,collection_key,rule_json,sort_json)
select id,'Needs pricing','needs-pricing',
  '{"statuses":["identified","researched"],"ownerPriceMissing":true}'::jsonb,
  '{"field":"research_priority_score","direction":"desc"}'::jsonb
from stores
on conflict(store_id,collection_key) do nothing;

insert into smart_collections(store_id,name,collection_key,rule_json,sort_json)
select id,'Collector pieces','collector-pieces',
  '{"statuses":["priced","ready"],"minimumCollectorScore":0.65}'::jsonb,
  '{"field":"collector_score","direction":"desc"}'::jsonb
from stores
on conflict(store_id,collection_key) do nothing;

insert into smart_collections(store_id,name,collection_key,rule_json,sort_json)
select id,'Move now','move-now',
  '{"statuses":["ready"],"minimumStaleScore":0.55}'::jsonb,
  '{"field":"stale_score","direction":"desc"}'::jsonb
from stores
on conflict(store_id,collection_key) do nothing;

alter table price_comparables
  add column if not exists garment_id uuid references garments(id) on delete cascade,
  add column if not exists source_listing_id text,
  add column if not exists canonical_key text,
  add column if not exists normalized_price_cents integer,
  add column if not exists normalized_currency char(3) default 'USD',
  add column if not exists stale_score numeric(8,5) default 0,
  add column if not exists duplicate_group_key text,
  add column if not exists rejected_reason text;

create index if not exists price_comparables_garment_idx
  on price_comparables(store_id,garment_id,observed_at desc);

alter table price_recommendations
  add column if not exists garment_id uuid references garments(id) on delete cascade,
  add column if not exists calibration_multiplier numeric(10,5) not null default 1,
  add column if not exists hostile_data_flags_json jsonb not null default '[]'::jsonb;

create index if not exists price_recommendations_garment_idx
  on price_recommendations(store_id,garment_id,created_at desc);

create table pricing_calibration_profiles (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references stores(id) on delete cascade,
  segment_key text not null,
  sample_size integer not null default 0,
  multiplier numeric(10,5) not null default 1,
  median_days_to_sell numeric(10,2),
  realized_to_recommended_ratio numeric(10,5),
  confidence numeric(8,5) not null default 0,
  updated_at timestamptz not null default now(),
  unique(store_id,segment_key)
);

create table comp_search_runs (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references stores(id) on delete cascade,
  garment_id uuid not null references garments(id) on delete cascade,
  status text not null check(status in ('queued','running','completed','failed','partial')),
  query_plan_json jsonb not null,
  provider_summary_json jsonb not null default '{}'::jsonb,
  hostile_data_flags_json jsonb not null default '[]'::jsonb,
  raw_candidate_count integer not null default 0,
  normalized_candidate_count integer not null default 0,
  accepted_comparable_count integer not null default 0,
  error_message text,
  created_at timestamptz not null default now(),
  completed_at timestamptz
);
create index comp_search_runs_garment_idx
  on comp_search_runs(store_id,garment_id,created_at desc);
