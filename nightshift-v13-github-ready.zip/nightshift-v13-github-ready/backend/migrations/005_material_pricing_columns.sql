
alter table price_recommendations
  add column if not exists material_history_premium_pct numeric(8,3) not null default 0,
  add column if not exists material_failure_penalty_pct numeric(8,3) not null default 0;
