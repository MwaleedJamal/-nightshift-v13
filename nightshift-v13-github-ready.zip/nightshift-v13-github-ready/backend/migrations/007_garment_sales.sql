alter table sale_items
  add column if not exists garment_id uuid references garments(id);

create unique index if not exists one_sale_per_garment
  on sale_items(store_id,garment_id)
  where garment_id is not null;
