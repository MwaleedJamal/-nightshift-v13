create extension if not exists pgcrypto;

create type membership_role as enum ('owner','admin','manager','cashier','viewer');
create type inventory_reason as enum ('initial','purchase','adjustment','sale','return','damage','import');
create type sale_status as enum ('completed','partially_refunded','refunded','void');
create type payment_method as enum ('cash','card','apple_pay','cash_app','venmo','zelle');
create type payment_status as enum ('pending','captured','failed','refunded','partially_refunded');
create type research_status as enum ('queued','running','completed','failed');

create table users (
  id uuid primary key default gen_random_uuid(),
  email text not null unique,
  display_name text not null,
  password_hash text not null,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table stores (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  created_at timestamptz not null default now()
);

create table memberships (
  store_id uuid not null references stores(id) on delete cascade,
  user_id uuid not null references users(id) on delete cascade,
  role membership_role not null,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  primary key (store_id,user_id)
);

create table store_settings (
  store_id uuid primary key references stores(id) on delete cascade,
  currency char(3) not null default 'USD',
  tax_basis_points int not null default 825 check (tax_basis_points between 0 and 10000),
  low_stock_default int not null default 1,
  receipt_footer text,
  sale_sequence bigint not null default 0,
  updated_at timestamptz not null default now()
);

create or replace function next_sale_number(p_store uuid)
returns text language plpgsql as $$
declare n bigint;
begin
  update store_settings set sale_sequence=sale_sequence+1, updated_at=now()
  where store_id=p_store
  returning sale_sequence into n;
  if n is null then raise exception 'store settings missing'; end if;
  return 'NS-' || lpad(n::text, 6, '0');
end $$;

create table products (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references stores(id) on delete cascade,
  name text not null,
  brand text,
  category text,
  description text,
  active boolean not null default true,
  created_by uuid references users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index products_store_idx on products(store_id,updated_at desc);

create table variants (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references stores(id) on delete cascade,
  product_id uuid not null references products(id) on delete cascade,
  sku text not null,
  barcode text,
  size text,
  color text,
  condition text not null default 'Good',
  cost_cents integer not null default 0 check (cost_cents >= 0),
  price_cents integer not null default 0 check (price_cents >= 0),
  low_stock_threshold integer not null default 1 check (low_stock_threshold >= 0),
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(store_id,sku),
  unique(store_id,barcode)
);
create index variants_store_product_idx on variants(store_id,product_id);

create table inventory_balances (
  store_id uuid not null references stores(id) on delete cascade,
  variant_id uuid not null references variants(id) on delete cascade,
  quantity integer not null default 0 check (quantity >= 0),
  updated_at timestamptz not null default now(),
  primary key(store_id,variant_id)
);

create table inventory_events (
  id bigserial primary key,
  store_id uuid not null references stores(id) on delete cascade,
  variant_id uuid not null references variants(id) on delete cascade,
  delta integer not null check (delta <> 0),
  reason inventory_reason not null,
  reference_type text,
  reference_id text,
  note text,
  actor_user_id uuid references users(id),
  created_at timestamptz not null default now()
);
create index inventory_events_variant_idx on inventory_events(store_id,variant_id,id desc);
create index inventory_events_created_idx on inventory_events(store_id,created_at desc);

create or replace function apply_inventory_event()
returns trigger language plpgsql as $$
declare current_qty integer;
begin
  select quantity into current_qty
  from inventory_balances
  where store_id=new.store_id and variant_id=new.variant_id
  for update;

  if current_qty is null then
    raise exception 'inventory balance missing for variant %', new.variant_id;
  end if;
  if current_qty + new.delta < 0 then
    raise exception 'insufficient stock for variant %', new.variant_id;
  end if;

  update inventory_balances
  set quantity=current_qty+new.delta, updated_at=now()
  where store_id=new.store_id and variant_id=new.variant_id;

  return new;
end $$;

create trigger trg_apply_inventory_event
after insert on inventory_events
for each row execute function apply_inventory_event();

create table sales (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references stores(id) on delete cascade,
  sale_number text not null,
  subtotal_cents integer not null check (subtotal_cents >= 0),
  discount_cents integer not null default 0 check (discount_cents >= 0),
  tax_cents integer not null default 0 check (tax_cents >= 0),
  total_cents integer not null check (total_cents >= 0),
  status sale_status not null default 'completed',
  created_by uuid references users(id),
  created_at timestamptz not null default now(),
  unique(store_id,sale_number)
);
create index sales_store_created_idx on sales(store_id,created_at desc);

create table sale_items (
  id uuid primary key default gen_random_uuid(),
  sale_id uuid not null references sales(id) on delete cascade,
  store_id uuid not null references stores(id) on delete cascade,
  variant_id uuid references variants(id),
  sku_snapshot text not null,
  product_name_snapshot text not null,
  variant_label_snapshot text,
  unit_price_cents integer not null,
  unit_cost_cents integer not null,
  quantity integer not null check (quantity > 0),
  returned_quantity integer not null default 0 check (returned_quantity >= 0),
  discount_cents integer not null default 0,
  line_total_cents integer not null,
  check (returned_quantity <= quantity)
);
create index sale_items_sale_idx on sale_items(store_id,sale_id);

create table payments (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references stores(id) on delete cascade,
  sale_id uuid not null references sales(id) on delete cascade,
  method payment_method not null,
  status payment_status not null,
  amount_cents integer not null,
  external_reference text,
  created_at timestamptz not null default now()
);
create index payments_sale_idx on payments(store_id,sale_id);

create table return_items (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references stores(id) on delete cascade,
  sale_id uuid not null references sales(id) on delete cascade,
  sale_item_id uuid not null references sale_items(id),
  quantity integer not null check (quantity > 0),
  refund_cents integer not null check (refund_cents >= 0),
  reason text,
  restocked boolean not null default true,
  created_by uuid references users(id),
  created_at timestamptz not null default now()
);
create index returns_sale_idx on return_items(store_id,sale_id);

create table expenses (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references stores(id) on delete cascade,
  expense_date date not null,
  category text not null,
  vendor text,
  description text,
  amount_cents integer not null check(amount_cents >= 0),
  created_by uuid references users(id),
  created_at timestamptz not null default now()
);
create index expenses_store_date_idx on expenses(store_id,expense_date desc);

create table research_jobs (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references stores(id) on delete cascade,
  variant_id uuid references variants(id),
  image_key text not null,
  status research_status not null default 'queued',
  notes text,
  result_json jsonb,
  error_message text,
  created_by uuid references users(id),
  created_at timestamptz not null default now(),
  started_at timestamptz,
  completed_at timestamptz
);
create index research_store_created_idx on research_jobs(store_id,created_at desc);

create table idempotency_keys (
  id bigserial primary key,
  store_id uuid not null references stores(id) on delete cascade,
  idempotency_key text not null,
  command text not null,
  status text not null check(status in ('in_progress','completed')),
  response_json jsonb,
  created_at timestamptz not null default now(),
  completed_at timestamptz,
  unique(store_id,idempotency_key,command)
);

create table audit_log (
  id bigserial primary key,
  store_id uuid not null references stores(id) on delete cascade,
  actor_user_id uuid references users(id),
  action text not null,
  entity_type text not null,
  entity_id text not null,
  before_json jsonb,
  after_json jsonb,
  metadata_json jsonb,
  created_at timestamptz not null default now()
);
create index audit_store_created_idx on audit_log(store_id,created_at desc);

create table outbox_events (
  id bigserial primary key,
  store_id uuid not null references stores(id) on delete cascade,
  event_type text not null,
  aggregate_type text not null,
  aggregate_id text not null,
  payload jsonb not null,
  created_at timestamptz not null default now(),
  dispatched_at timestamptz
);
create index outbox_pending_idx on outbox_events(id) where dispatched_at is null;
