create table garment_intelligence_profiles (
  garment_id uuid primary key references garments(id) on delete cascade,
  store_id uuid not null references stores(id) on delete cascade,

  identity_confidence numeric(8,5) not null default 0
    check(identity_confidence between 0 and 1),

  rarity_score numeric(8,5) not null default 0
    check(rarity_score between -1 and 1),
  wear_character_score numeric(8,5) not null default 0
    check(wear_character_score between -1 and 1),
  cultural_desirability_score numeric(8,5) not null default 0
    check(cultural_desirability_score between -1 and 1),
  damage_risk numeric(8,5) not null default 0
    check(damage_risk between 0 and 1),
  provenance_score numeric(8,5) not null default 0
    check(provenance_score between -1 and 1),

  material_identity_confidence numeric(8,5) not null default 0
    check(material_identity_confidence between 0 and 1),
  material_historical_value numeric(8,5) not null default 0
    check(material_historical_value between -1 and 1),
  material_rarity numeric(8,5) not null default 0
    check(material_rarity between -1 and 1),
  material_collector_demand numeric(8,5) not null default 0
    check(material_collector_demand between -1 and 1),
  material_age_character numeric(8,5) not null default 0
    check(material_age_character between -1 and 1),
  material_failure_risk numeric(8,5) not null default 0
    check(material_failure_risk between 0 and 1),
  material_evidence_state material_evidence_state not null default 'UNKNOWN_UNVERIFIED',

  identity_json jsonb not null default '{}'::jsonb,
  material_json jsonb not null default '{}'::jsonb,
  wear_json jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

create table garment_price_decisions (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references stores(id) on delete cascade,
  garment_id uuid not null references garments(id) on delete cascade,
  recommendation_id uuid references price_recommendations(id),
  chosen_price_cents integer not null check(chosen_price_cents >= 0),
  chosen_by uuid references users(id),
  decision_note text,
  created_at timestamptz not null default now()
);
create index garment_price_decisions_garment_idx
  on garment_price_decisions(store_id,garment_id,created_at desc);
