
create type vintage_signal_kind as enum (
  'identity',
  'rarity',
  'wear_character',
  'damage_risk',
  'cultural_desirability',
  'construction',
  'provenance'
);

create table garment_profiles (
  variant_id uuid primary key references variants(id) on delete cascade,
  store_id uuid not null references stores(id) on delete cascade,
  era_start_year integer,
  era_end_year integer,
  era_label text,
  country_of_manufacture text,
  tag_generation text,
  construction_json jsonb not null default '{}'::jsonb,
  measurements_json jsonb not null default '{}'::jsonb,
  identity_json jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

create table vintage_signals (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references stores(id) on delete cascade,
  variant_id uuid not null references variants(id) on delete cascade,
  kind vintage_signal_kind not null,
  signal_key text not null,
  score numeric(8,5) not null check(score between -1 and 1),
  confidence numeric(8,5) not null check(confidence between 0 and 1),
  evidence_set_id uuid references evidence_sets(id),
  details_json jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index vintage_signals_variant_idx
  on vintage_signals(store_id,variant_id,kind,created_at desc);

create table price_comparables (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references stores(id) on delete cascade,
  variant_id uuid not null references variants(id) on delete cascade,
  source_name text not null,
  source_url text,
  listing_type text not null check(listing_type in ('sold','active','archive','retail','other')),
  title text not null,
  currency char(3) not null default 'USD',
  price_cents integer not null check(price_cents >= 0),
  sold_at timestamptz,
  observed_at timestamptz not null default now(),
  match_score numeric(8,5) not null check(match_score between 0 and 1),
  evidence_json jsonb not null default '{}'::jsonb,
  unique(store_id,variant_id,source_url)
);
create index price_comparables_variant_idx
  on price_comparables(store_id,variant_id,observed_at desc);

create table price_recommendations (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references stores(id) on delete cascade,
  variant_id uuid not null references variants(id) on delete cascade,
  decision_session_id uuid references decision_sessions(id),
  model_config_id uuid references model_configs(id),
  evidence_set_id uuid references evidence_sets(id),
  quick_sale_cents integer not null check(quick_sale_cents >= 0),
  target_cents integer not null check(target_cents >= 0),
  collector_ask_cents integer not null check(collector_ask_cents >= 0),
  floor_cents integer not null check(floor_cents >= 0),
  confidence numeric(8,5) not null check(confidence between 0 and 1),
  rarity_premium_pct numeric(8,3) not null default 0,
  wear_character_premium_pct numeric(8,3) not null default 0,
  cultural_premium_pct numeric(8,3) not null default 0,
  damage_penalty_pct numeric(8,3) not null default 0,
  reasoning_json jsonb not null,
  source_summary_json jsonb not null,
  created_at timestamptz not null default now()
);
create index price_recommendations_variant_idx
  on price_recommendations(store_id,variant_id,created_at desc);

create table price_decisions (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references stores(id) on delete cascade,
  variant_id uuid not null references variants(id) on delete cascade,
  recommendation_id uuid references price_recommendations(id),
  chosen_price_cents integer not null check(chosen_price_cents >= 0),
  chosen_by uuid references users(id),
  decision_note text,
  created_at timestamptz not null default now()
);

create table realized_price_outcomes (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references stores(id) on delete cascade,
  variant_id uuid not null references variants(id) on delete cascade,
  recommendation_id uuid references price_recommendations(id),
  listed_price_cents integer,
  sold_price_cents integer,
  days_to_sell integer,
  gross_margin_cents integer,
  sold_at timestamptz,
  created_at timestamptz not null default now()
);
