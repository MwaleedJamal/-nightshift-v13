# This file describes the transactional retail core.
# For the full governed architecture see COUNTERGRID_V12_ARCHITECTURE.md.

# NIGHTSHIFT backend architecture

## Shape

```text
Browser / Native app
        |
        v
Fastify API (/v1)
  |        |          \
  |        |           \--> MinIO/S3 pre-signed media
  |        |
  |        +--> Redis/BullMQ --> Worker --> research provider
  |
  +--> PostgreSQL
       ├─ transactional write model
       ├─ inventory ledger
       ├─ inventory balance projection
       ├─ sales + returns
       ├─ audit log
       └─ transactional outbox
```

## Domain boundaries

### Identity
users, stores, memberships, JWT and role authorization.

### Catalog
products and variants. The SKU is stable. Price/cost are cents.

### Inventory
`inventory_events` is the source of truth. Events are `initial`, `purchase`,
`adjustment`, `sale`, `return`, `damage`, and `import`.

An `AFTER INSERT` trigger applies each event to `inventory_balances`. The trigger
rejects any event that would make stock negative.

### Sales
Checkout locks the requested inventory balance rows in deterministic order,
validates availability, snapshots price/cost/name/sku, writes the sale and sale
items, writes sale inventory events, writes the payment, and emits a
`sale.completed` outbox event before commit.

### Returns
Returns lock the sale and its sale items, prevent over-returning, calculate a
proportional refund, optionally append return inventory events, and update the
sale status.

### Idempotency
Dangerous commands accept `Idempotency-Key`. The first caller claims the key.
Subsequent callers get the stored response rather than creating duplicate sales.

### Outbox
Domain events are never published directly from a request transaction. They are
inserted into `outbox_events`. A worker polls undispatched rows and moves them
onto Redis. This avoids "database committed but event publish failed" races.

### Research
Research is asynchronous. Upload a source image to object storage, create a
research job, enqueue it, then poll `/v1/research/:id`. The default provider is a
safe stub; `RESEARCH_WEBHOOK_URL` can point at a real vision/web-comps service.

### Reporting
Reports query transactional data directly in v1. At higher scale, outbox events
can feed ClickHouse/BigQuery without changing the command model.

## Scale path

- API replicas are stateless.
- Postgres is the consistency authority.
- Redis is disposable acceleration/job infrastructure, not the source of truth.
- Media is object storage.
- Partition `inventory_events`, `audit_log`, and `outbox_events` by month/store
  when volume warrants it.
- Add read replicas for reporting.
- Push outbox events to Kafka when Redis queue throughput becomes insufficient.
- Add a warehouse for long-range BI.
