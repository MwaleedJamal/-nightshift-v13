# NIGHTSHIFT V13 API flow

## Intake a garment

`POST /v1/garments`

```json
{
  "displayName": "Carhartt Detroit Jacket",
  "brand": "Carhartt",
  "category": "Jackets",
  "acquisitionCostCents": 3200,
  "sourceName": "Estate buy"
}
```

Response includes the unique garment SKU and barcode.

## Search / sort

`GET /v1/garments?status=ready&sort=collector`

Supported sort modes:
- `newest`
- `price_high`
- `price_low`
- `collector`
- `move_fast`
- `stale`
- `research`

## Barcode lookup

`GET /v1/garments/by-barcode/:barcode`

## Set the owner price

`POST /v1/garments/:id/price`

```json
{
  "ownerPriceCents": 14500,
  "recommendationId": "optional-uuid",
  "note": "Holding for collector buyer"
}
```

## Mark ready

`POST /v1/garments/:id/ready`

## Register scan

`GET /v1/pos/scan/:barcode`

The register sees only sellable fields.

## Checkout

`POST /v1/pos/checkout`

Headers:
- `Authorization: Bearer ...`
- `x-store-id: ...`
- `Idempotency-Key: device-sale-unique-id`

```json
{
  "garmentIds": [
    "uuid-1",
    "uuid-2"
  ],
  "paymentMethod": "card",
  "paymentStatus": "captured"
}
```

Every garment is locked during checkout and moves from `ready` to `sold`
inside the same transaction.
