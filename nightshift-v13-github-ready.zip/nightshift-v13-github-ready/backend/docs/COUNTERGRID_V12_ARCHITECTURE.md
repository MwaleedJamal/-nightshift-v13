# NIGHTSHIFT × CounterGrid V12 Architecture

NIGHTSHIFT adopts the core architecture that emerged in CounterGrid V12:
a deterministic operating core, a governed control plane, a probabilistic
intelligence field, a thin experience layer, and a durable memory plane.

The key rule is simple:

> Intelligence can recommend. Only the deterministic control path can authorize and execute.

## 1. Planes

### Truth Plane
Owns:
- inventory
- products and variants
- money
- payments
- expenses
- store settings
- policies and policy versions
- immutable domain events
- bitemporal state
- provenance
- projections

Truth data is strongly consistent where correctness matters.

### Control Plane
Owns:
- identity
- RBAC + ABAC
- policy evaluation
- approval requirements
- write-time revalidation
- action permissions
- execution modes
- idempotency
- Action Gateway
- durable workflows

### Intelligence Plane
Owns:
- pricing recommendations
- demand forecasts
- slow-stock scoring
- replenishment proposals
- fraud/risk scoring
- product-identification research
- scenario simulation
- explanation
- uncertainty

Intelligence is never the source of truth.

### Experience Plane
Owns:
- REST API
- web/native-facing BFF
- query projections
- mobile-friendly sync contracts
- operator UX state

### Memory Plane
Owns:
- decision sessions
- interventions
- human choice
- outcomes
- evaluation
- learned institutional memory

## 2. Backward decision flow

Every consequential decision follows:

desired outcome
→ candidate action
→ evidence
→ feasibility
→ constraints
→ authority
→ store/jurisdiction
→ policy version
→ execution mode
→ execution
→ realized outcome
→ learning

`UNKNOWN_UNVERIFIED` can never authorize execution.

## 3. Decision modes

- `RECOMMEND` — safe to show as a recommended action.
- `HUMAN_REVIEW` — needs explicit human approval.
- `SHADOW` — calculate and log, but do not surface as an actionable recommendation.
- `ABSTAIN` — insufficient evidence or confidence.
- `BLOCK` — explicitly prohibited.

The mode is a deterministic Control Plane result, not a model opinion.

## 4. Action Gateway

Every consequential mutation is executed through the Action Gateway.

The Action Gateway:
1. loads current truth
2. verifies the actor
3. resolves role + attributes
4. resolves current policy pack + version
5. evaluates constraints
6. checks evidence provenance
7. checks model/recommendation lineage if present
8. derives execution mode
9. rejects if not executable
10. executes inside a transaction
11. records immutable lineage
12. emits an outbox event

## 5. Bitemporal truth

Policy, pricing, tax, settings, and selected operational state support:
- valid time: when a rule/state applies in the real world
- system time: when NIGHTSHIFT learned/stored it

This prevents later edits from rewriting historical truth.

## 6. Versioning

The following must create new versions rather than silently overwrite history:
- policy packs
- store rules
- tax rules
- pricing rules
- payment policies
- research/model configs
- automation configs
- recommendation strategies

Executed actions keep immutable links to:
- truth snapshot
- policy version
- model/config version
- evidence set
- actor
- approval
- execution mode
- outcome

## 7. Intervention graph

The memory model is:

context
→ recommendation
→ human decision
→ execution
→ outcome
→ evaluation
→ learned policy/model feedback

This is how NIGHTSHIFT becomes smarter without letting probabilistic systems
directly mutate authoritative state.

## 8. Regional/store cells

At scale:
- stores belong to regional cells
- each cell can own operational writes
- global analytics remain eventually consistent
- money, inventory, permissions, and execution remain strongly consistent
- forecasts and simulations may be eventually consistent

## 9. Edge/offline posture

The mobile app may queue proposed actions offline, but:
- it does not finalize authoritative inventory or money offline
- reconnect sends commands with idempotency keys
- the server revalidates against current truth and policy before commit

## 10. High-level topology

```text
Native / Web UI
      |
Experience Plane
      |
Decision API
      |
Control Plane
  ├── RBAC/ABAC
  ├── Policy Engine
  ├── Decision Modes
  ├── Approval Engine
  └── Action Gateway
      |
Truth Plane
  ├── Postgres
  ├── event ledger
  ├── bitemporal state
  ├── money
  ├── inventory
  └── outbox
      |
+------------------------------+
| Intelligence Plane           |
| forecasts / pricing / AI     |
| recommendations / simulation |
+------------------------------+
      |
Memory Plane
  ├── decision sessions
  ├── interventions
  ├── outcomes
  └── evaluation
```
