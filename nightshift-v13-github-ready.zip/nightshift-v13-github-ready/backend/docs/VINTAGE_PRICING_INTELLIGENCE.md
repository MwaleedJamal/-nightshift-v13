
# NIGHTSHIFT Vintage Pricing Intelligence

NIGHTSHIFT must not use a generic retail "condition discount" model.

In vintage clothing, wear can be a value signal.

Examples:
- sun fading can increase desirability
- honeycombs / whiskering in denim can increase desirability
- paint, workwear wear, distressing, repairs, and patina can increase value
- cracked graphics can be desirable
- rare tags / production eras can materially change value
- single-stitch construction, made-in-country tags, licensed graphics, original labels,
  deadstock status, subculture relevance and provenance can dominate ordinary "condition"

But damage is not automatically valuable.

A torn generic shirt is not worth more simply because it is damaged.

## Vintage-specific concept model

Instead of one scalar `condition`, NIGHTSHIFT separates:

### Identity
- brand
- model
- garment type
- era
- tag / label generation
- country of manufacture
- fabric / construction
- graphic / license / collaboration
- measurements and silhouette

### Rarity
- production scarcity
- tag scarcity
- graphic scarcity
- size scarcity
- colorway scarcity
- regional scarcity

### Wear character
- fade
- patina
- distress
- cracking
- fraying
- paint / work marks
- repairs
- wash character
- denim whiskering / honeycombs
- oxidation / hardware aging

### Damage risk
Separate from wear character:
- structural seam failure
- holes that threaten wearability
- active dry rot
- severe staining with low aesthetic value
- missing critical hardware
- odor / contamination
- fabric instability

Wear character can create a premium.
Damage risk can create a discount or block.

### Cultural desirability
- current vintage trend strength
- collector demand
- subculture relevance
- celebrity / music / skate / motorsport / workwear relevance
- silhouette demand
- brand heat
- seasonal demand

### Market evidence
Evidence classes are weighted differently:

1. Exact sold comps
2. Near-exact sold comps
3. Exact active listings
4. Near-exact active listings
5. Retail/archive references
6. General web references

Sold evidence dominates asking-price evidence.

## Price output

NIGHTSHIFT should not output one unexplained number.

It outputs:

- `quickSaleCents`
- `targetCents`
- `collectorAskCents`
- `floorCents`
- confidence
- evidence coverage
- comparable count
- wear premium
- rarity premium
- cultural premium
- damage penalty
- reasoning
- source provenance

Example:

```json
{
  "quickSaleCents": 9500,
  "targetCents": 11800,
  "collectorAskCents": 13500,
  "floorCents": 9000,
  "confidence": 0.88,
  "adjustments": {
    "rarityPremiumPct": 12,
    "wearCharacterPremiumPct": 18,
    "culturalPremiumPct": 10,
    "damagePenaltyPct": 0
  }
}
```

## Key pricing rule

Authentic age and aesthetically desirable wear can increase price.

The engine only applies a wear premium when:
1. the item identity is sufficiently confident
2. comparable market evidence supports it OR a versioned vintage policy allows it
3. the wear is categorized as `wear_character`, not `damage_risk`
4. the item remains wearable/collectible
5. the system records why the premium was applied

Otherwise it must abstain or request human review.

## Learning loop

NIGHTSHIFT should learn from the owner's own transactions:

recommendation
→ owner accepted / changed
→ listed price
→ sale price
→ days to sell
→ realized margin
→ future pricing calibration

This allows NIGHTSHIFT to learn the difference between:
- internet theoretical value
- the owner's actual customer base
- what moves quickly
- what deserves a patient collector ask
