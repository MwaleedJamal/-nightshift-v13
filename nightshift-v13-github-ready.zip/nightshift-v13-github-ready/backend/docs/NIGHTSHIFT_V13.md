# NIGHTSHIFT V13 — Garment Intelligence Core

NIGHTSHIFT is a private vintage-clothing operating system.

It is not an ecommerce storefront.

The primary object is the **physical garment**.

Every physical garment receives:
- an immutable NIGHTSHIFT garment id
- a human-readable SKU
- a unique internal EAN-13 barcode
- media
- identity evidence
- era/tag/construction evidence
- material history
- vintage wear character
- damage/failure risk
- global market comparables
- a price recommendation
- the owner's final price
- a physical rack/location
- a complete event history
- final sale outcome

## Golden path

```text
ARRIVES
  ↓
INBOX
  ↓
PHOTO / MANUAL IDENTITY
  ↓
GARMENT FINGERPRINT
  ↓
SKU + BARCODE
  ↓
GLOBAL COMP SEARCH
  ↓
NORMALIZE + DEDUPE + MATCH SCORE
  ↓
VINTAGE + MATERIAL REASONING
  ↓
PRICE LAB
  ↓
OWNER APPROVES / CHANGES
  ↓
READY + RACK LOCATION
  ↓
SCAN AT REGISTER
  ↓
SOLD
  ↓
OUTCOME → LEARNING
```

## Product surfaces

### INBOX
Unprocessed garments. The goal is throughput:
photo → identify → barcode → research → price → ready.

### INVENTORY
All garments, intelligently searchable and sortable.

### PRICE LAB
Private to the owner. Global evidence, exact/near-exact comps,
material/era/tag history, pricing recommendation and confidence.

### REGISTER
Deliberately simple:
scan barcode → garment appears → choose payment → complete sale.

## CounterGrid V12 beneath the UI

The UI does not expose governance jargon during normal work.

Underneath:
- deterministic Truth Plane
- Control Plane
- probabilistic Intelligence Plane
- Experience Plane
- Memory Plane
- provenance
- Action Gateway
- idempotency
- versioned policy
- recommendation lineage
- outcomes
- evaluation
- hostile-data pressure testing
- UNKNOWN_UNVERIFIED cannot authorize premiums or execution

## Pricing doctrine

NIGHTSHIFT does not ask "what condition is this?"

It asks:

1. What exactly is this garment?
2. What era/tag/construction does it belong to?
3. What material history does it carry?
4. Is the wear authentic and desirable?
5. Is there structural/material failure?
6. How rare is the exact configuration?
7. How culturally desirable is it now?
8. What have genuinely comparable pieces sold for?
9. How trustworthy are those sources?
10. What happens in *this store* when similar pieces are priced at different levels?

The result is a range, not fake precision:
- floor
- quick sale
- target
- collector ask
- confidence
- explicit reasoning

## Internet-wide research

Search providers are adapters.

NIGHTSHIFT does not hardwire its intelligence to one marketplace.

Each provider returns normalized candidates:
- source
- listing id
- URL
- title
- sold/active/archive status
- price
- currency
- observed date
- attributes
- raw evidence

The pipeline then:
- canonicalizes
- deduplicates
- converts currency using an injected FX provider
- rejects or downweights stale records
- scores exactness
- detects outliers
- separates sold evidence from asking evidence
- records provenance

No configured provider means no invented data.
