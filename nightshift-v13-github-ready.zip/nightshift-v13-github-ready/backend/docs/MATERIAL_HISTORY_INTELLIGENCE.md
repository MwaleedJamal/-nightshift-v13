
# NIGHTSHIFT Material History Intelligence

Material history is a first-class vintage value signal.

A vintage garment is not described adequately by a modern e-commerce field such as
`material = cotton`.

NIGHTSHIFT tracks the material's genealogy:

## Material identity

- fiber composition
- fabric family
- weave / knit
- fabric weight
- yarn character
- dye / pigment process
- wash / finishing process
- coating
- tanning process for leather
- hardware material
- lining / insulation
- mill / textile producer when known
- country / region of textile manufacture
- garment-manufacturing country
- production era

## Historical significance

Examples of signals NIGHTSHIFT can represent:

- period-correct fabric construction
- discontinued fabric or finish
- historically important textile mill
- uncommon fiber blend for the era
- older manufacturing process
- heavyweight / specialty weave
- selvedge-style construction
- loopwheel-style knit construction
- natural aging characteristics
- period dye / fade behavior
- leather patina behavior
- original hardware/material pairing
- era-specific synthetic textile
- military / industrial / workwear textile specification

These are data categories, not automatic value claims.

## Evidence levels

Each material-history assertion must have provenance.

### VERIFIED
Supported by label/tag, manufacturer documentation, catalog/archive, mill record,
trusted reference, or sufficiently distinctive construction evidence.

### PARTIAL
Strongly inferred but not fully documented.

### UNKNOWN_UNVERIFIED
Plausible, but not safe to use as an execution-grade pricing signal.

### CONTRADICTED
Evidence conflicts with the claim.

`UNKNOWN_UNVERIFIED` material history does not authorize a pricing premium.

## Material aging vs garment damage

Material aging can itself be desirable:

- denim fading
- leather patina
- canvas abrasion
- wool character
- nylon aging
- pigment fading
- oxidation of period hardware

But NIGHTSHIFT separates:

`material_age_character`
from
`material_failure_risk`

Examples of failure risk:
- dry rot
- hydrolysis
- severe fiber embrittlement
- delamination
- unstable coating
- active mold
- structural leather cracking

The first may increase collector value.
The second may reduce value or trigger review.

## Pricing role

Material history contributes an explicit, bounded pricing adjustment.

Example:

```json
{
  "materialHistoryPremiumPct": 14,
  "reason": [
    "Verified period textile construction",
    "Scarce fabric variant",
    "Aging behavior desirable in current vintage market"
  ]
}
```

The adjustment is gated by:

1. material identity confidence
2. evidence state
3. historical relevance
4. rarity
5. comparable-market support when available
6. absence of severe material failure

## Learning

NIGHTSHIFT retains:

material profile
→ material-history claim
→ evidence
→ recommended premium
→ owner's chosen price
→ realized sale price
→ days to sell

Over time this lets NIGHTSHIFT learn which material histories matter in the owner's
actual vintage market rather than relying only on generic internet lore.
