import test from "node:test";
import assert from "node:assert/strict";
import {
  normalizeCandidates,dedupeCandidates
} from "../src/intelligence/comp-normalizer.js";
import { robustPriceFilter } from "../src/intelligence/robust-filter.js";

test("normalizer dedupes repeated listing identity",()=>{
  const now=new Date().toISOString();
  const rows=normalizeCandidates([
    {
      sourceName:"x",sourceListingId:"123",title:"Vintage Jacket",
      listingType:"active",priceMinor:10000,currency:"USD",observedAt:now
    },
    {
      sourceName:"x",sourceListingId:"123",title:"Vintage Jacket",
      listingType:"active",priceMinor:10000,currency:"USD",observedAt:now
    }
  ],n=>n,"USD");
  assert.equal(dedupeCandidates(rows).length,1);
});

test("robust filter rejects extreme price outlier",()=>{
  const rows=[
    10000,10100,9900,10300,9800,10200,10050,999999
  ].map((price,i)=>({
    normalizedPriceCents:price,
    id:String(i)
  }));
  const result=robustPriceFilter(rows);
  assert.equal(result.accepted.some(x=>x.normalizedPriceCents===999999),false);
});
