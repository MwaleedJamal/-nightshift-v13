import test from "node:test";
import assert from "node:assert/strict";
import { computeGarmentSortScores } from "../src/intelligence/sorting-engine.js";

test("rare culturally desirable garment ranks as collector piece",()=>{
  const s=computeGarmentSortScores({
    confidence:.95,
    targetPriceCents:18000,
    acquisitionCostCents:3000,
    rarity:.9,
    culturalDemand:.85,
    materialHistoricalValue:.8,
    wearCharacter:.7,
    daysInInventory:5,
    comparableCount:12,
    soldComparableCount:7
  });
  assert.ok(s.collectorScore>.75);
  assert.ok(s.researchPriorityScore<.4);
});

test("weakly researched rare garment gets research priority",()=>{
  const s=computeGarmentSortScores({
    confidence:.35,
    targetPriceCents:0,
    acquisitionCostCents:2000,
    rarity:.8,
    culturalDemand:.5,
    materialHistoricalValue:.8,
    wearCharacter:.5,
    daysInInventory:1,
    comparableCount:1,
    soldComparableCount:0
  });
  assert.ok(s.researchPriorityScore>.6);
});
