import test from "node:test";
import assert from "node:assert/strict";

test("money arithmetic stays integer cents", () => {
  const items = [
    { price: 12000, qty: 1 },
    { price: 8800, qty: 2 }
  ];
  const subtotal = items.reduce((s,x) => s + x.price*x.qty, 0);
  const tax = Math.round(subtotal * 825 / 10_000);
  assert.equal(subtotal, 29600);
  assert.equal(tax, 2442);
  assert.equal(subtotal + tax, 32042);
});
