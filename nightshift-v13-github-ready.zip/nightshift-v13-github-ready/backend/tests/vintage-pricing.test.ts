
import test from "node:test";
import assert from "node:assert/strict";
import { recommendVintagePrice } from "../src/vintage/pricing-engine.js";

const now = new Date();

test("desirable wear can increase vintage target price", () => {
  const comps = [
    { source:"a", listingType:"sold" as const, priceCents:10000, matchScore:.95, observedAt:now },
    { source:"b", listingType:"sold" as const, priceCents:10500, matchScore:.90, observedAt:now },
    { source:"c", listingType:"active" as const, priceCents:12500, matchScore:.88, observedAt:now }
  ];

  const clean = recommendVintagePrice(comps,{
    identityConfidence:.95,
    rarity:.2,
    wearCharacter:0,
    culturalDesirability:.2,
    damageRisk:0,
    provenance:0
  });

  const patina = recommendVintagePrice(comps,{
    identityConfidence:.95,
    rarity:.2,
    wearCharacter:.8,
    culturalDesirability:.2,
    damageRisk:0,
    provenance:0
  });

  assert.ok(patina.targetCents > clean.targetCents);
  assert.ok(patina.adjustments.wearCharacterPremiumPct > 0);
});

test("structural damage can outweigh desirable wear", () => {
  const comps = [
    { source:"a", listingType:"sold" as const, priceCents:10000, matchScore:.95, observedAt:now },
    { source:"b", listingType:"sold" as const, priceCents:11000, matchScore:.92, observedAt:now }
  ];

  const result = recommendVintagePrice(comps,{
    identityConfidence:.95,
    rarity:.3,
    wearCharacter:.8,
    culturalDesirability:.3,
    damageRisk:.95,
    provenance:0
  });

  assert.ok(result.adjustments.damagePenaltyPct > result.adjustments.wearCharacterPremiumPct);
});

test("wear premium is gated when identity confidence is weak", () => {
  const comps = [
    { source:"a", listingType:"sold" as const, priceCents:10000, matchScore:.8, observedAt:now }
  ];

  const result = recommendVintagePrice(comps,{
    identityConfidence:.4,
    rarity:.2,
    wearCharacter:1,
    culturalDesirability:.2,
    damageRisk:0,
    provenance:0
  });

  assert.ok(result.adjustments.wearCharacterPremiumPct <= 1);
});
