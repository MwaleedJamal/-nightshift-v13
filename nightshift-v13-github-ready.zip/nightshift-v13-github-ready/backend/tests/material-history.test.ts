
import test from "node:test";
import assert from "node:assert/strict";
import { assessMaterialHistory } from "../src/vintage/material-history-engine.js";
import { recommendVintagePrice } from "../src/vintage/pricing-engine.js";

test("verified historically significant material can add value", () => {
  const result = assessMaterialHistory({
    identityConfidence:.95,
    evidenceState:"VERIFIED",
    historicalSignificance:.8,
    rarity:.6,
    currentCollectorDemand:.7,
    ageCharacter:.5,
    materialFailureRisk:0
  });

  assert.equal(result.usableForPricing,true);
  assert.ok(result.premiumPct > 10);
  assert.equal(result.failurePenaltyPct,0);
});

test("unverified material history cannot create a premium", () => {
  const result = assessMaterialHistory({
    identityConfidence:.95,
    evidenceState:"UNKNOWN_UNVERIFIED",
    historicalSignificance:1,
    rarity:1,
    currentCollectorDemand:1,
    ageCharacter:1,
    materialFailureRisk:0
  });

  assert.equal(result.usableForPricing,false);
  assert.equal(result.premiumPct,0);
});

test("material failure can outweigh historical premium", () => {
  const result = assessMaterialHistory({
    identityConfidence:.95,
    evidenceState:"VERIFIED",
    historicalSignificance:.8,
    rarity:.8,
    currentCollectorDemand:.7,
    ageCharacter:.8,
    materialFailureRisk:.9
  });

  assert.ok(result.failurePenaltyPct > result.premiumPct);
});

test("pricing engine includes verified material history", () => {
  const now = new Date();
  const comps = [
    { source:"a", listingType:"sold" as const, priceCents:10000, matchScore:.95, observedAt:now },
    { source:"b", listingType:"sold" as const, priceCents:10500, matchScore:.92, observedAt:now }
  ];

  const base = recommendVintagePrice(comps,{
    identityConfidence:.95,
    rarity:0,
    wearCharacter:0,
    culturalDesirability:0,
    damageRisk:0,
    provenance:0
  });

  const material = recommendVintagePrice(comps,{
    identityConfidence:.95,
    rarity:0,
    wearCharacter:0,
    culturalDesirability:0,
    damageRisk:0,
    provenance:0,
    materialIdentityConfidence:.95,
    materialHistoricalValue:.9,
    materialRarity:.7,
    materialCollectorDemand:.7,
    materialAgeCharacter:.6,
    materialFailureRisk:0,
    materialEvidenceState:"VERIFIED"
  });

  assert.ok(material.targetCents > base.targetCents);
  assert.ok(material.adjustments.materialHistoryPremiumPct > 0);
});
