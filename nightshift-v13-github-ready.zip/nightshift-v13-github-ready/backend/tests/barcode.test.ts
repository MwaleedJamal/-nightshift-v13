import test from "node:test";
import assert from "node:assert/strict";
import { ean13FromPayload } from "../src/domain/barcode.js";

test("EAN-13 generator emits 13 numeric digits",()=>{
  const code=ean13FromPayload("290010000001");
  assert.match(code,/^\d{13}$/);
});

test("EAN checksum is deterministic",()=>{
  assert.equal(
    ean13FromPayload("290010000001"),
    ean13FromPayload("290010000001")
  );
});
