import test from "node:test";
import assert from "node:assert/strict";
import { calibratePriceMultiplier } from "../src/intelligence/price-learning.js";

test("calibration resists overreacting to tiny samples",()=>{
  const one=calibratePriceMultiplier([{
    recommendedTargetCents:10000,
    chosenPriceCents:15000,
    soldPriceCents:15000,
    daysToSell:1
  }]);
  assert.ok(one.multiplier < 1.08);
});

test("calibration learns with repeated outcomes",()=>{
  const rows=Array.from({length:30},()=>({
    recommendedTargetCents:10000,
    chosenPriceCents:12000,
    soldPriceCents:12000,
    daysToSell:12
  }));
  const result=calibratePriceMultiplier(rows);
  assert.ok(result.multiplier > 1.1);
  assert.ok(result.confidence > 0.5);
});
