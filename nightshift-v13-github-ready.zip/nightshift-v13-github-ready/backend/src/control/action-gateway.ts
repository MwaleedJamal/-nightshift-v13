import type { DbClient } from "../db.js";
import type { Role } from "../types.js";
import { AppError } from "../lib/errors.js";
import { createDecisionSession } from "./decision-service.js";
import type { DecisionMode, EvidenceState } from "./policy-engine.js";
import { emitOutbox } from "../lib/outbox.js";

export async function actionGateway<T>(
  db: DbClient,
  input: {
    storeId: string;
    actorUserId: string;
    role: Role;
    desiredOutcome: string;
    actionType: string;
    actionPayload: unknown;
    evidenceState: EvidenceState;
    evidenceType?: string;
    evidence?: unknown;
    provenance?: unknown;
    requestedMode?: DecisionMode;
    stateSnapshot: unknown;
    modelConfigId?: string | null;
    idempotencyKey: string;
  },
  execute: (decision: {
    decisionSessionId: string;
    mode: DecisionMode;
    policyPackId: string | null;
    evidenceSetId: string | null;
  }) => Promise<T>
): Promise<T | { decisionSessionId: string; mode: DecisionMode; executable: false }> {
  const existing = await db.query(
    `select response_json,status from action_executions
     where store_id=$1 and idempotency_key=$2 and action_type=$3
     for update`,
    [input.storeId,input.idempotencyKey,input.actionType]
  );
  if (existing.rows[0]?.status === "executed") return existing.rows[0].response_json;

  const decision = await createDecisionSession(db, input);

  await db.query(
    `insert into action_executions
     (store_id,decision_session_id,action_type,idempotency_key,mode,policy_pack_id,
      evidence_set_id,model_config_id,actor_user_id,request_json,status)
     values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,'accepted')
     on conflict(store_id,idempotency_key,action_type) do nothing`,
    [
      input.storeId,decision.id,input.actionType,input.idempotencyKey,decision.mode,
      decision.policy_pack_id,decision.evidence_set_id,input.modelConfigId ?? null,
      input.actorUserId,input.actionPayload
    ]
  );

  if (decision.mode === "BLOCK") {
    await db.query(
      `update action_executions set status='rejected',completed_at=now()
       where store_id=$1 and idempotency_key=$2 and action_type=$3`,
      [input.storeId,input.idempotencyKey,input.actionType]
    );
    throw new AppError(403,"Action blocked by current policy","POLICY_BLOCK");
  }

  if (decision.mode === "ABSTAIN" || decision.mode === "SHADOW" || decision.mode === "HUMAN_REVIEW") {
    if (decision.mode === "HUMAN_REVIEW") {
      await db.query(
        `insert into approvals
         (store_id,decision_session_id,requested_from_role,status)
         values ($1,$2,'manager','pending')`,
        [input.storeId,decision.id]
      );
    }
    return { decisionSessionId: decision.id, mode: decision.mode, executable: false };
  }

  const result = await execute({
    decisionSessionId: decision.id,
    mode: decision.mode,
    policyPackId: decision.policy_pack_id,
    evidenceSetId: decision.evidence_set_id
  });

  await db.query(
    `update action_executions
     set status='executed',response_json=$4,completed_at=now()
     where store_id=$1 and idempotency_key=$2 and action_type=$3`,
    [input.storeId,input.idempotencyKey,input.actionType,result]
  );

  await emitOutbox(
    db,
    input.storeId,
    "action.executed",
    "decision_session",
    decision.id,
    { actionType: input.actionType, result }
  );

  return result;
}
