import type { DbClient } from "../db.js";
import type { Role } from "../types.js";

export type DecisionMode = "RECOMMEND" | "HUMAN_REVIEW" | "SHADOW" | "ABSTAIN" | "BLOCK";
export type EvidenceState = "VERIFIED" | "PARTIAL" | "UNKNOWN_UNVERIFIED" | "CONTRADICTED";

const roleRank: Record<Role, number> = {
  viewer: 0,
  cashier: 1,
  manager: 2,
  admin: 3,
  owner: 4
};

function stricter(a: DecisionMode, b: DecisionMode): DecisionMode {
  const order: DecisionMode[] = ["RECOMMEND","HUMAN_REVIEW","SHADOW","ABSTAIN","BLOCK"];
  return order[Math.max(order.indexOf(a), order.indexOf(b))]!;
}

export async function evaluatePolicy(
  db: DbClient,
  input: {
    storeId: string;
    actionType: string;
    role: Role;
    evidenceState: EvidenceState;
    requestedMode?: DecisionMode;
  }
): Promise<{
  mode: DecisionMode;
  policyPackId: string | null;
  rationale: Record<string, unknown>;
}> {
  const { rows } = await db.query(
    `select id,rules_json
     from policy_packs
     where store_id=$1
       and policy_key='retail-core'
       and status='active'
       and valid_from<=now()
       and (valid_to is null or valid_to>now())
     order by version desc
     limit 1`,
    [input.storeId]
  );

  const policy = rows[0];
  const rules = policy?.rules_json ?? {};
  const actionRule = rules?.actions?.[input.actionType] ?? {};
  const minimumRole = (actionRule.minimumRole ?? "owner") as Role;
  let mode = (actionRule.defaultMode ?? "HUMAN_REVIEW") as DecisionMode;

  if (roleRank[input.role] < roleRank[minimumRole]) mode = "BLOCK";

  if (input.evidenceState === "UNKNOWN_UNVERIFIED") mode = stricter(mode, "ABSTAIN");
  if (input.evidenceState === "CONTRADICTED") mode = "BLOCK";

  if (input.requestedMode) mode = stricter(mode, input.requestedMode);

  return {
    mode,
    policyPackId: policy?.id ?? null,
    rationale: {
      actionType: input.actionType,
      role: input.role,
      minimumRole,
      evidenceState: input.evidenceState,
      requestedMode: input.requestedMode ?? null
    }
  };
}
