import type { DbClient } from "../db.js";
import type { Role } from "../types.js";
import { evaluatePolicy, type DecisionMode, type EvidenceState } from "./policy-engine.js";

export async function createDecisionSession(
  db: DbClient,
  input: {
    storeId: string;
    actorUserId: string;
    role: Role;
    desiredOutcome: string;
    candidateAction: string;
    actionPayload: unknown;
    evidenceState: EvidenceState;
    evidenceType?: string;
    evidence?: unknown;
    provenance?: unknown;
    requestedMode?: DecisionMode;
    stateSnapshot: unknown;
    modelConfigId?: string | null;
  }
) {
  let evidenceSetId: string | null = null;

  if (input.evidenceType || input.evidence) {
    const evidence = await db.query(
      `insert into evidence_sets
       (store_id,evidence_type,state,provenance_json,evidence_json)
       values ($1,$2,$3,$4,$5)
       returning id`,
      [
        input.storeId,
        input.evidenceType ?? "generic",
        input.evidenceState,
        input.provenance ?? {},
        input.evidence ?? {}
      ]
    );
    evidenceSetId = evidence.rows[0].id;
  }

  const policy = await evaluatePolicy(db, {
    storeId: input.storeId,
    actionType: input.candidateAction,
    role: input.role,
    evidenceState: input.evidenceState,
    requestedMode: input.requestedMode
  });

  const session = await db.query(
    `insert into decision_sessions
     (store_id,actor_user_id,desired_outcome,candidate_action,action_payload,
      evidence_set_id,policy_pack_id,model_config_id,mode,rationale_json,state_snapshot_json)
     values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
     returning id,mode,policy_pack_id,evidence_set_id,created_at`,
    [
      input.storeId,
      input.actorUserId,
      input.desiredOutcome,
      input.candidateAction,
      input.actionPayload,
      evidenceSetId,
      policy.policyPackId,
      input.modelConfigId ?? null,
      policy.mode,
      policy.rationale,
      input.stateSnapshot
    ]
  );

  return session.rows[0];
}
