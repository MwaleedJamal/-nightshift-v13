import { Worker } from "bullmq";
import { pool } from "./db.js";
import { eventQueue, redis, priceResearchQueue } from "./lib/queue.js";
import { config } from "./config.js";
import { presignedGet } from "./lib/storage.js";
import { configuredCompProviders, convertConfiguredCurrency } from "./intelligence/providers/registry.js";
import { runCompResearch } from "./intelligence/research-orchestrator.js";

const researchWorker = new Worker(
  "research",
  async job => {
    const id = String(job.data.researchJobId);
    const claimed = await pool.query(
      `update research_jobs set status='running', started_at=now()
       where id=$1 and status='queued'
       returning id,store_id,image_key,variant_id,notes`,
      [id]
    );
    const row = claimed.rows[0];
    if (!row) return;

    try {
      let result: unknown;
      if (config.RESEARCH_PROVIDER === "webhook") {
        if (!config.RESEARCH_WEBHOOK_URL) throw new Error("RESEARCH_WEBHOOK_URL is required");
        const imageUrl = await presignedGet(row.image_key, 600);
        const response = await fetch(config.RESEARCH_WEBHOOK_URL, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({
            jobId: row.id,
            storeId: row.store_id,
            variantId: row.variant_id,
            imageUrl,
            notes: row.notes
          })
        });
        if (!response.ok) throw new Error(`Research provider returned ${response.status}`);
        result = await response.json();
      } else {
        await new Promise(r => setTimeout(r, 400));
        result = {
          provider: "stub",
          liveData: false,
          identification: { title: "Unconfigured research provider", confidence: 0 },
          pricing: null,
          sources: [],
          note: "Connect a real vision/web-comps provider with RESEARCH_PROVIDER=webhook."
        };
      }

      await pool.query(
        `update research_jobs set status='completed', result_json=$2, completed_at=now() where id=$1`,
        [id, result]
      );
    } catch (error) {
      await pool.query(
        `update research_jobs set status='failed', error_message=$2, completed_at=now() where id=$1`,
        [id, error instanceof Error ? error.message : String(error)]
      );
      throw error;
    }
  },
  { connection: redis, concurrency: 4 }
);


const priceResearchWorker = new Worker(
  "price-research",
  async job => {
    const searchRunId=String(job.data.searchRunId);

    const claim=await pool.query(
      `update comp_search_runs
       set status='running'
       where id=$1 and status='queued'
       returning *`,
      [searchRunId]
    );
    const run=claim.rows[0];
    if (!run) return;

    try {
      const profile=await pool.query(
        `select p.identity_confidence,p.identity_json,p.material_json,
                g.brand,g.category
         from garments g
         left join garment_intelligence_profiles p
           on p.garment_id=g.id and p.store_id=g.store_id
         where g.id=$1 and g.store_id=$2`,
        [run.garment_id,run.store_id]
      );
      const row=profile.rows[0];
      if (!row) throw new Error("Garment missing");

      const identity=row.identity_json ?? {};
      const material=row.material_json ?? {};
      const providers=configuredCompProviders();

      if (!providers.length) {
        await pool.query(
          `update comp_search_runs
           set status='partial',
               provider_summary_json=$2,
               hostile_data_flags_json=$3,
               error_message='No comp search providers configured',
               completed_at=now()
           where id=$1`,
          [
            searchRunId,
            {},
            [{
              code:"NO_PROVIDERS",
              severity:"critical",
              detail:"No live internet search providers are configured."
            }]
          ]
        );
        return;
      }

      const research=await runCompResearch({
        identity:{
          brand:identity.brand ?? row.brand,
          model:identity.model ?? null,
          garmentType:identity.garmentType ?? row.category,
          eraLabel:identity.eraLabel ?? null,
          tagGeneration:identity.tagGeneration ?? null,
          graphicOrLicense:identity.graphicOrLicense ?? null,
          color:identity.color ?? null,
          materialTerms:Array.isArray(material.searchTerms)
            ? material.searchTerms
            : []
        },
        identityConfidence:Number(row.identity_confidence ?? 0),
        providers,
        convertCurrency:convertConfiguredCurrency,
        targetCurrency:"USD"
      });

      const client=await pool.connect();
      try {
        await client.query("BEGIN");

        for (const comp of research.accepted) {
          await client.query(
            `insert into price_comparables
             (store_id,garment_id,variant_id,source_name,source_listing_id,
              source_url,listing_type,title,currency,price_cents,sold_at,
              observed_at,match_score,evidence_json,canonical_key,
              normalized_price_cents,normalized_currency,stale_score,
              duplicate_group_key)
             values
             ($1,$2,null,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18)
             on conflict do nothing`,
            [
              run.store_id,run.garment_id,comp.sourceName,
              comp.sourceListingId ?? null,comp.sourceUrl ?? null,
              comp.listingType,comp.title,comp.currency,
              comp.priceMinor,comp.soldAt ? new Date(comp.soldAt) : null,
              new Date(comp.observedAt),
              0.50,
              comp.raw ?? comp.attributes ?? {},
              comp.canonicalKey,comp.normalizedPriceCents,
              comp.normalizedCurrency,comp.staleScore,
              comp.duplicateGroupKey
            ]
          );
        }

        await client.query(
          `update comp_search_runs
           set status=$2,
               query_plan_json=$3,
               provider_summary_json=$4,
               hostile_data_flags_json=$5,
               raw_candidate_count=$6,
               normalized_candidate_count=$7,
               accepted_comparable_count=$8,
               completed_at=now()
           where id=$1`,
          [
            searchRunId,
            Object.values(research.providerSummary).every((x:any)=>x.ok)
              ? "completed"
              : "partial",
            research.plan,research.providerSummary,research.flags,
            research.rawCount,research.normalizedCount,
            research.accepted.length
          ]
        );

        await client.query("COMMIT");
      } catch (error) {
        await client.query("ROLLBACK");
        throw error;
      } finally {
        client.release();
      }
    } catch (error) {
      await pool.query(
        `update comp_search_runs
         set status='failed',error_message=$2,completed_at=now()
         where id=$1`,
        [searchRunId,error instanceof Error ? error.message : String(error)]
      );
      throw error;
    }
  },
  { connection: redis, concurrency: 3 }
);


async function pumpOutbox() {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const { rows } = await client.query(
      `select id,store_id,event_type,aggregate_type,aggregate_id,payload
       from outbox_events
       where dispatched_at is null
       order by id
       for update skip locked
       limit 100`
    );
    for (const row of rows) {
      await eventQueue.add(row.event_type, row, {
        jobId: `outbox-${row.id}`,
        removeOnComplete: 1000,
        removeOnFail: 1000
      });
      await client.query(`update outbox_events set dispatched_at=now() where id=$1`, [row.id]);
    }
    await client.query("COMMIT");
  } catch (error) {
    await client.query("ROLLBACK");
    console.error("outbox pump failed", error);
  } finally {
    client.release();
  }
}

const timer = setInterval(() => void pumpOutbox(), 1000);
void pumpOutbox();

async function shutdown() {
  clearInterval(timer);
  await researchWorker.close();
  await priceResearchWorker.close();
  await redis.quit();
  await pool.end();
}
process.on("SIGTERM", () => void shutdown().then(() => process.exit(0)));
process.on("SIGINT", () => void shutdown().then(() => process.exit(0)));

console.log("NIGHTSHIFT worker online");
