import { Queue } from "bullmq";
import IORedis from "ioredis";
import { config } from "../config.js";

export const redis = new IORedis(config.REDIS_URL, { maxRetriesPerRequest: null });
export const researchQueue = new Queue("research", { connection: redis });
export const eventQueue = new Queue("domain-events", { connection: redis });

export const priceResearchQueue = new Queue("price-research", { connection: redis });
