import type { DbClient } from "../db.js";

export async function emitOutbox(
  db: DbClient,
  storeId: string,
  eventType: string,
  aggregateType: string,
  aggregateId: string,
  payload: unknown
) {
  await db.query(
    `insert into outbox_events
      (store_id, event_type, aggregate_type, aggregate_id, payload)
     values ($1,$2,$3,$4,$5)`,
    [storeId, eventType, aggregateType, aggregateId, payload]
  );
}
