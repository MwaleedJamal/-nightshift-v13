import type { DbClient } from "../db.js";

export async function audit(
  db: DbClient,
  input: {
    storeId: string;
    actorUserId: string | null;
    action: string;
    entityType: string;
    entityId: string;
    before?: unknown;
    after?: unknown;
    metadata?: unknown;
  }
) {
  await db.query(
    `insert into audit_log
      (store_id, actor_user_id, action, entity_type, entity_id, before_json, after_json, metadata_json)
     values ($1,$2,$3,$4,$5,$6,$7,$8)`,
    [
      input.storeId,
      input.actorUserId,
      input.action,
      input.entityType,
      input.entityId,
      input.before ?? null,
      input.after ?? null,
      input.metadata ?? null
    ]
  );
}
