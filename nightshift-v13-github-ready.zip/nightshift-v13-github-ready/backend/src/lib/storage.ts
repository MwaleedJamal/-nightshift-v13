import { Client } from "minio";
import { config } from "../config.js";

export const storage = new Client({
  endPoint: config.MINIO_ENDPOINT,
  port: config.MINIO_PORT,
  useSSL: config.MINIO_USE_SSL,
  accessKey: config.MINIO_ACCESS_KEY,
  secretKey: config.MINIO_SECRET_KEY
});

export async function ensureBucket() {
  const exists = await storage.bucketExists(config.MINIO_BUCKET);
  if (!exists) await storage.makeBucket(config.MINIO_BUCKET);
}

export async function presignedPut(objectName: string, expiresSeconds = 900) {
  await ensureBucket();
  return storage.presignedPutObject(config.MINIO_BUCKET, objectName, expiresSeconds);
}

export async function presignedGet(objectName: string, expiresSeconds = 900) {
  await ensureBucket();
  return storage.presignedGetObject(config.MINIO_BUCKET, objectName, expiresSeconds);
}
