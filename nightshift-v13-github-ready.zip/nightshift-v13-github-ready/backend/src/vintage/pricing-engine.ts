import { assessMaterialHistory } from "./material-history-engine.js";

export type Comparable = {
  source: string;
  listingType: "sold" | "active" | "archive" | "retail" | "other";
  priceCents: number;
  matchScore: number;
  observedAt: Date;
};

export type VintageSignals = {
  identityConfidence: number;
  rarity: number;               // -1..1
  wearCharacter: number;        // -1..1
  culturalDesirability: number; // -1..1
  damageRisk: number;           // 0..1
  provenance: number;           // -1..1

  // Material-history signals are optional for backward compatibility.
  materialIdentityConfidence?: number; // 0..1
  materialHistoricalValue?: number;    // -1..1
  materialRarity?: number;             // -1..1
  materialCollectorDemand?: number;    // -1..1
  materialAgeCharacter?: number;       // -1..1
  materialFailureRisk?: number;        // 0..1
  materialEvidenceState?: "VERIFIED" | "PARTIAL" | "UNKNOWN_UNVERIFIED" | "CONTRADICTED";
};

export type VintagePriceRecommendation = {
  quickSaleCents: number;
  targetCents: number;
  collectorAskCents: number;
  floorCents: number;
  confidence: number;
  adjustments: {
    rarityPremiumPct: number;
    wearCharacterPremiumPct: number;
    culturalPremiumPct: number;
    provenancePremiumPct: number;
    materialHistoryPremiumPct: number;
    materialFailurePenaltyPct: number;
    damagePenaltyPct: number;
  };
  evidence: {
    exactLikeSoldCount: number;
    soldCount: number;
    activeCount: number;
    weightedMedianCents: number;
  };
  reasoning: string[];
};

const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));

function weightedMedian(rows: Array<{ value: number; weight: number }>): number {
  if (!rows.length) return 0;
  const sorted = [...rows].sort((a,b) => a.value-b.value);
  const total = sorted.reduce((s,r) => s+r.weight,0);
  let running = 0;
  for (const row of sorted) {
    running += row.weight;
    if (running >= total / 2) return row.value;
  }
  return sorted.at(-1)!.value;
}

function freshnessWeight(observedAt: Date): number {
  const ageDays = Math.max(0, (Date.now() - observedAt.getTime()) / 86_400_000);
  if (ageDays <= 30) return 1;
  if (ageDays <= 90) return 0.92;
  if (ageDays <= 180) return 0.82;
  if (ageDays <= 365) return 0.70;
  return 0.55;
}

function listingWeight(type: Comparable["listingType"]): number {
  switch (type) {
    case "sold": return 1.00;
    case "active": return 0.48;
    case "archive": return 0.38;
    case "retail": return 0.25;
    default: return 0.18;
  }
}

export function recommendVintagePrice(
  comparables: Comparable[],
  signals: VintageSignals
): VintagePriceRecommendation {
  const usable = comparables
    .filter(c => c.priceCents > 0 && c.matchScore >= 0.35)
    .map(c => ({
      ...c,
      weight: listingWeight(c.listingType) *
        clamp(c.matchScore,0,1) ** 2 *
        freshnessWeight(c.observedAt)
    }))
    .filter(c => c.weight > 0.03);

  if (!usable.length) {
    return {
      quickSaleCents: 0,
      targetCents: 0,
      collectorAskCents: 0,
      floorCents: 0,
      confidence: 0,
      adjustments: {
        rarityPremiumPct: 0,
        wearCharacterPremiumPct: 0,
        culturalPremiumPct: 0,
        provenancePremiumPct: 0,
        materialHistoryPremiumPct: 0,
        materialFailurePenaltyPct: 0,
        damagePenaltyPct: 0
      },
      evidence: {
        exactLikeSoldCount: 0,
        soldCount: 0,
        activeCount: 0,
        weightedMedianCents: 0
      },
      reasoning: ["Insufficient market evidence. Human pricing required."]
    };
  }

  const base = weightedMedian(usable.map(c => ({ value:c.priceCents, weight:c.weight })));

  // These are intentionally bounded. Policy/model versions can change the caps later.
  const rarityPremiumPct = clamp(signals.rarity * 22, -8, 22);
  const culturalPremiumPct = clamp(signals.culturalDesirability * 20, -10, 20);
  const provenancePremiumPct = clamp(signals.provenance * 12, -5, 12);

  const materialAssessment = assessMaterialHistory({
    identityConfidence: signals.materialIdentityConfidence ?? signals.identityConfidence,
    evidenceState: signals.materialEvidenceState ?? "UNKNOWN_UNVERIFIED",
    historicalSignificance: signals.materialHistoricalValue ?? 0,
    rarity: signals.materialRarity ?? 0,
    currentCollectorDemand: signals.materialCollectorDemand ?? 0,
    ageCharacter: signals.materialAgeCharacter ?? 0,
    materialFailureRisk: signals.materialFailureRisk ?? 0
  });

  const materialHistoryPremiumPct = materialAssessment.premiumPct;
  const materialFailurePenaltyPct = materialAssessment.failurePenaltyPct;

  // Wear premium only activates meaningfully when identity confidence is strong.
  // This prevents random damage from being misread as valuable patina.
  const wearGate = clamp((signals.identityConfidence - 0.55) / 0.30, 0, 1);
  const wearCharacterPremiumPct = clamp(signals.wearCharacter * 28 * wearGate, -8, 28);

  // Damage is separate from patina and can dominate if structural risk is high.
  const damagePenaltyPct = clamp(signals.damageRisk * 45, 0, 45);

  const netPct =
    rarityPremiumPct +
    culturalPremiumPct +
    provenancePremiumPct +
    materialHistoryPremiumPct +
    wearCharacterPremiumPct -
    materialFailurePenaltyPct -
    damagePenaltyPct;

  const target = Math.max(0, Math.round(base * (1 + netPct / 100)));
  const quick = Math.round(target * 0.84);
  const collector = Math.round(target * (1.12 + Math.max(0, signals.rarity) * 0.08));
  const floor = Math.round(target * 0.76);

  const sold = usable.filter(c => c.listingType === "sold");
  const exactLikeSold = sold.filter(c => c.matchScore >= 0.82);
  const active = usable.filter(c => c.listingType === "active");

  const evidenceCoverage = clamp(
    exactLikeSold.length * 0.12 +
    sold.length * 0.055 +
    active.length * 0.018,
    0,
    1
  );

  const confidence = clamp(
    0.15 +
    signals.identityConfidence * 0.38 +
    evidenceCoverage * 0.42 +
    (1 - Math.min(1, signals.damageRisk)) * 0.05,
    0,
    0.98
  );

  const reasoning: string[] = [
    `Market anchor: ${(base/100).toFixed(2)} weighted median.`,
  ];
  if (rarityPremiumPct > 1) reasoning.push(`Rarity supports +${rarityPremiumPct.toFixed(1)}%.`);
  if (wearCharacterPremiumPct > 1) reasoning.push(`Authentic desirable wear/patina supports +${wearCharacterPremiumPct.toFixed(1)}%.`);
  if (culturalPremiumPct > 1) reasoning.push(`Current cultural demand supports +${culturalPremiumPct.toFixed(1)}%.`);
  if (provenancePremiumPct > 1) reasoning.push(`Provenance supports +${provenancePremiumPct.toFixed(1)}%.`);
  reasoning.push(...materialAssessment.reasoning);
  if (damagePenaltyPct > 1) reasoning.push(`Structural/non-aesthetic damage reduces value by ${damagePenaltyPct.toFixed(1)}%.`);
  if (signals.identityConfidence < 0.70) reasoning.push("Identity confidence is limited; wear premium is gated.");

  return {
    quickSaleCents: quick,
    targetCents: target,
    collectorAskCents: collector,
    floorCents: floor,
    confidence,
    adjustments: {
      rarityPremiumPct,
      wearCharacterPremiumPct,
      culturalPremiumPct,
      provenancePremiumPct,
      materialHistoryPremiumPct,
      materialFailurePenaltyPct,
      damagePenaltyPct
    },
    evidence: {
      exactLikeSoldCount: exactLikeSold.length,
      soldCount: sold.length,
      activeCount: active.length,
      weightedMedianCents: base
    },
    reasoning
  };
}
