
export type MatchFeatures = {
  brandExact: boolean;
  modelExact: boolean;
  garmentTypeExact: boolean;
  eraMatch: number;          // 0..1
  tagGenerationMatch: number;// 0..1
  graphicMatch: number;      // 0..1
  colorMatch: number;        // 0..1
  sizeComparable: number;    // 0..1
  constructionMatch: number; // 0..1
  wearCharacterMatch: number;// 0..1
};

export function comparableMatchScore(f: MatchFeatures): number {
  const raw =
    (f.brandExact ? 0.16 : 0) +
    (f.modelExact ? 0.22 : 0) +
    (f.garmentTypeExact ? 0.10 : 0) +
    f.eraMatch * 0.11 +
    f.tagGenerationMatch * 0.10 +
    f.graphicMatch * 0.10 +
    f.colorMatch * 0.05 +
    f.sizeComparable * 0.04 +
    f.constructionMatch * 0.06 +
    f.wearCharacterMatch * 0.06;

  return Math.min(1, Math.max(0, raw));
}
