
export type MaterialEvidenceState =
  | "VERIFIED"
  | "PARTIAL"
  | "UNKNOWN_UNVERIFIED"
  | "CONTRADICTED";

export type MaterialHistoryInput = {
  identityConfidence: number;
  evidenceState: MaterialEvidenceState;

  historicalSignificance: number; // -1..1
  rarity: number;                 // -1..1
  currentCollectorDemand: number; // -1..1

  ageCharacter: number;           // -1..1
  materialFailureRisk: number;    // 0..1
};

export type MaterialHistoryAssessment = {
  premiumPct: number;
  failurePenaltyPct: number;
  netPct: number;
  usableForPricing: boolean;
  reasoning: string[];
};

const clamp = (v:number,lo:number,hi:number) => Math.min(hi,Math.max(lo,v));

export function assessMaterialHistory(
  input: MaterialHistoryInput
): MaterialHistoryAssessment {
  const reasoning: string[] = [];

  if (input.evidenceState === "CONTRADICTED") {
    return {
      premiumPct: 0,
      failurePenaltyPct: clamp(input.materialFailureRisk * 50,0,50),
      netPct: -clamp(input.materialFailureRisk * 50,0,50),
      usableForPricing: false,
      reasoning: ["Material-history claim is contradicted."]
    };
  }

  if (input.evidenceState === "UNKNOWN_UNVERIFIED") {
    return {
      premiumPct: 0,
      failurePenaltyPct: clamp(input.materialFailureRisk * 50,0,50),
      netPct: -clamp(input.materialFailureRisk * 50,0,50),
      usableForPricing: false,
      reasoning: [
        "Material history is unverified; NIGHTSHIFT will not apply a material premium."
      ]
    };
  }

  const evidenceFactor = input.evidenceState === "VERIFIED" ? 1 : 0.62;
  const identityGate = clamp((input.identityConfidence - 0.50) / 0.35,0,1);

  const historical = clamp(input.historicalSignificance, -1, 1) * 10;
  const rarity = clamp(input.rarity,-1,1) * 10;
  const demand = clamp(input.currentCollectorDemand,-1,1) * 8;
  const ageCharacter = clamp(input.ageCharacter,-1,1) * 7;

  const premiumPct = clamp(
    (historical + rarity + demand + ageCharacter) *
      evidenceFactor *
      identityGate,
    -10,
    30
  );

  const failurePenaltyPct = clamp(input.materialFailureRisk * 50,0,50);
  const netPct = premiumPct - failurePenaltyPct;

  if (historical > 1) reasoning.push(
    `Historical textile significance contributes +${(historical*evidenceFactor*identityGate).toFixed(1)}%.`
  );
  if (rarity > 1) reasoning.push(
    `Material scarcity contributes +${(rarity*evidenceFactor*identityGate).toFixed(1)}%.`
  );
  if (demand > 1) reasoning.push(
    `Collector demand for this material contributes +${(demand*evidenceFactor*identityGate).toFixed(1)}%.`
  );
  if (ageCharacter > 1) reasoning.push(
    `Desirable material aging contributes +${(ageCharacter*evidenceFactor*identityGate).toFixed(1)}%.`
  );
  if (failurePenaltyPct > 1) reasoning.push(
    `Material failure risk reduces value by ${failurePenaltyPct.toFixed(1)}%.`
  );
  if (input.evidenceState === "PARTIAL") reasoning.push(
    "Material history is partially verified, so the premium is dampened."
  );
  if (input.identityConfidence < 0.70) reasoning.push(
    "Material identity confidence limits the premium."
  );

  return {
    premiumPct,
    failurePenaltyPct,
    netPct,
    usableForPricing: true,
    reasoning
  };
}
