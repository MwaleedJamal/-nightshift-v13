import type { FastifyInstance, FastifyRequest } from "fastify";
import jwt from "@fastify/jwt";
import { pool } from "../db.js";
import type { Role } from "../types.js";
import { AppError } from "../lib/errors.js";
import { config } from "../config.js";

const rank: Record<Role, number> = {
  viewer: 0,
  cashier: 1,
  manager: 2,
  admin: 3,
  owner: 4
};

export async function authPlugin(app: FastifyInstance) {
  await app.register(jwt, { secret: config.JWT_SECRET });

  app.decorate("authenticate", async function (request: FastifyRequest) {
    try {
      const payload = await request.jwtVerify<{ sub: string; email: string }>();
      request.authUser = { userId: payload.sub, email: payload.email };
    } catch {
      throw new AppError(401, "Authentication required", "AUTH_REQUIRED");
    }
  });
}

export async function loadStoreContext(request: FastifyRequest) {
  if (!request.authUser) throw new AppError(401, "Authentication required");
  const storeId = String(request.headers["x-store-id"] ?? "");
  if (!storeId) throw new AppError(400, "x-store-id header is required", "STORE_REQUIRED");

  const { rows } = await pool.query(
    `select role from memberships where store_id=$1 and user_id=$2 and active=true`,
    [storeId, request.authUser.userId]
  );
  if (!rows[0]) throw new AppError(403, "No access to this store", "STORE_FORBIDDEN");

  request.storeId = storeId;
  request.role = rows[0].role as Role;
}

export function requireRole(minimum: Role) {
  return async function (request: FastifyRequest) {
    await loadStoreContext(request);
    if (!request.role || rank[request.role] < rank[minimum]) {
      throw new AppError(403, "Insufficient role", "ROLE_FORBIDDEN");
    }
  };
}
