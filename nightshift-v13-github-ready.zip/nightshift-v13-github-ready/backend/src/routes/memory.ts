import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { pool, tx } from "../db.js";
import { requireRole } from "../plugins/auth.js";

const interventionSchema = z.object({
  decisionSessionId: z.string().uuid(),
  actionType: z.string().min(1).max(160),
  targetType: z.string().min(1).max(120),
  targetId: z.string().min(1).max(200),
  chosenAction: z.string().max(500).optional()
});

const outcomeSchema = z.object({
  outcomeType: z.string().min(1).max(120),
  observed: z.unknown(),
  measuredAt: z.string().datetime()
});

export async function memoryRoutes(app: FastifyInstance) {
  app.post(
    "/v1/interventions",
    { preHandler: [app.authenticate, requireRole("manager")] },
    async (request, reply) => {
      const body = interventionSchema.parse(request.body);
      const result = await pool.query(
        `insert into interventions
         (store_id,decision_session_id,action_type,target_type,target_id,status,chosen_by,chosen_action)
         values ($1,$2,$3,$4,$5,'approved',$6,$7)
         returning *`,
        [
          request.storeId,body.decisionSessionId,body.actionType,body.targetType,
          body.targetId,request.authUser!.userId,body.chosenAction ?? null
        ]
      );
      reply.code(201).send(result.rows[0]);
    }
  );

  app.post(
    "/v1/interventions/:id/outcomes",
    { preHandler: [app.authenticate, requireRole("manager")] },
    async (request, reply) => {
      const id = (request.params as { id: string }).id;
      const body = outcomeSchema.parse(request.body);

      const result = await tx(async db => {
        const outcome = await db.query(
          `insert into outcomes
           (store_id,intervention_id,outcome_type,observed_json,measured_at)
           values ($1,$2,$3,$4,$5)
           returning *`,
          [request.storeId,id,body.outcomeType,body.observed,new Date(body.measuredAt)]
        );
        await db.query(
          `update interventions set status='observed'
           where id=$1 and store_id=$2`,
          [id,request.storeId]
        );
        return outcome.rows[0];
      });

      reply.code(201).send(result);
    }
  );

  app.get(
    "/v1/interventions/:id/lineage",
    { preHandler: [app.authenticate, requireRole("viewer")] },
    async (request) => {
      const id = (request.params as { id: string }).id;
      const result = await pool.query(
        `select i.*,
                row_to_json(ds) as decision,
                coalesce(json_agg(distinct o) filter (where o.id is not null),'[]') as outcomes,
                coalesce(json_agg(distinct er) filter (where er.id is not null),'[]') as evaluations
         from interventions i
         join decision_sessions ds on ds.id=i.decision_session_id
         left join outcomes o on o.intervention_id=i.id
         left join evaluation_runs er on er.intervention_id=i.id
         where i.id=$1 and i.store_id=$2
         group by i.id,ds.id`,
        [id,request.storeId]
      );
      return result.rows[0] ?? { error: "not_found" };
    }
  );
}
