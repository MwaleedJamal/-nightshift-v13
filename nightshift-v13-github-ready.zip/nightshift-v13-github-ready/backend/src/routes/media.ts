import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { requireRole } from "../plugins/auth.js";
import { presignedPut, presignedGet } from "../lib/storage.js";

const uploadSchema = z.object({
  fileName: z.string().min(1).max(180),
  contentType: z.string().min(3).max(120)
});

function cleanName(value: string) {
  return value.replace(/[^a-zA-Z0-9._-]/g, "_").slice(0, 120);
}

export async function mediaRoutes(app: FastifyInstance) {
  app.post("/v1/media/upload-url", { preHandler: [app.authenticate, requireRole("cashier")] }, async (request) => {
    const body = uploadSchema.parse(request.body);
    if (!body.contentType.startsWith("image/")) {
      throw new Error("Only image uploads are enabled in v1");
    }
    const key = `stores/${request.storeId}/images/${Date.now()}-${cleanName(body.fileName)}`;
    const url = await presignedPut(key);
    return { key, url, expiresSeconds: 900 };
  });

  app.get("/v1/media/url", { preHandler: [app.authenticate, requireRole("viewer")] }, async (request) => {
    const key = String((request.query as { key?: string }).key ?? "");
    if (!key.startsWith(`stores/${request.storeId}/`)) throw new Error("Invalid media key");
    return { url: await presignedGet(key), expiresSeconds: 900 };
  });
}
