import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { pool, tx } from "../db.js";
import { requireRole } from "../plugins/auth.js";
import { appendInventoryEvent } from "../domain/inventory.js";
import { audit } from "../lib/audit.js";

const createSchema = z.object({
  name: z.string().min(1).max(160),
  brand: z.string().max(120).nullable().optional(),
  category: z.string().max(80).nullable().optional(),
  sku: z.string().min(1).max(80),
  barcode: z.string().max(80).nullable().optional(),
  size: z.string().max(80).nullable().optional(),
  color: z.string().max(80).nullable().optional(),
  costCents: z.number().int().nonnegative(),
  priceCents: z.number().int().nonnegative(),
  initialQuantity: z.number().int().nonnegative().default(0),
  lowStockThreshold: z.number().int().nonnegative().default(1)
});

const adjustSchema = z.object({
  delta: z.number().int().refine(v => v !== 0),
  reason: z.enum(["purchase","adjustment","damage","import"]),
  note: z.string().max(500).optional()
});

export async function inventoryRoutes(app: FastifyInstance) {
  app.get("/v1/inventory", { preHandler: [app.authenticate, requireRole("viewer")] }, async (request) => {
    const result = await pool.query(
      `select v.id as variant_id, p.id as product_id, p.name, p.brand, p.category,
              v.sku, v.barcode, v.size, v.color, v.cost_cents, v.price_cents,
              v.low_stock_threshold, b.quantity
       from variants v
       join products p on p.id=v.product_id and p.store_id=v.store_id
       join inventory_balances b on b.variant_id=v.id and b.store_id=v.store_id
       where v.store_id=$1 and v.active=true and p.active=true
       order by p.updated_at desc, p.name`,
      [request.storeId]
    );
    return { items: result.rows };
  });

  app.post("/v1/inventory", { preHandler: [app.authenticate, requireRole("manager")] }, async (request, reply) => {
    const body = createSchema.parse(request.body);
    const result = await tx(async db => {
      const product = await db.query(
        `insert into products (store_id,name,brand,category,created_by)
         values ($1,$2,$3,$4,$5) returning id`,
        [request.storeId, body.name, body.brand ?? null, body.category ?? null, request.authUser!.userId]
      );
      const variant = await db.query(
        `insert into variants
          (store_id,product_id,sku,barcode,size,color,cost_cents,price_cents,low_stock_threshold)
         values ($1,$2,$3,$4,$5,$6,$7,$8,$9)
         returning id`,
        [
          request.storeId, product.rows[0].id, body.sku, body.barcode ?? null,
          body.size ?? null, body.color ?? null, body.costCents, body.priceCents, body.lowStockThreshold
        ]
      );
      await db.query(
        `insert into inventory_balances (store_id,variant_id,quantity) values ($1,$2,0)`,
        [request.storeId, variant.rows[0].id]
      );
      if (body.initialQuantity > 0) {
        await appendInventoryEvent(db, {
          storeId: request.storeId!,
          variantId: variant.rows[0].id,
          delta: body.initialQuantity,
          reason: "initial",
          actorUserId: request.authUser!.userId
        });
      }
      await audit(db, {
        storeId: request.storeId!,
        actorUserId: request.authUser!.userId,
        action: "catalog.variant.created",
        entityType: "variant",
        entityId: variant.rows[0].id,
        after: body
      });
      return { productId: product.rows[0].id, variantId: variant.rows[0].id };
    });
    reply.code(201).send(result);
  });

  app.post("/v1/inventory/:variantId/adjust", { preHandler: [app.authenticate, requireRole("manager")] }, async (request) => {
    const body = adjustSchema.parse(request.body);
    const variantId = (request.params as { variantId: string }).variantId;
    return tx(db => appendInventoryEvent(db, {
      storeId: request.storeId!,
      variantId,
      delta: body.delta,
      reason: body.reason,
      note: body.note,
      actorUserId: request.authUser!.userId
    }));
  });
}
