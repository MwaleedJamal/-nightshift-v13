import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { pool, tx } from "../db.js";
import { requireRole } from "../plugins/auth.js";
import { audit } from "../lib/audit.js";

const schema = z.object({
  expenseDate: z.string(),
  category: z.string().min(1).max(100),
  vendor: z.string().max(160).nullable().optional(),
  description: z.string().max(500).nullable().optional(),
  amountCents: z.number().int().nonnegative()
});

export async function expenseRoutes(app: FastifyInstance) {
  app.get("/v1/expenses", { preHandler: [app.authenticate, requireRole("manager")] }, async (request) => {
    const result = await pool.query(
      `select * from expenses where store_id=$1 order by expense_date desc, created_at desc limit 500`,
      [request.storeId]
    );
    return { expenses: result.rows };
  });

  app.post("/v1/expenses", { preHandler: [app.authenticate, requireRole("manager")] }, async (request, reply) => {
    const body = schema.parse(request.body);
    const result = await tx(async db => {
      const row = await db.query(
        `insert into expenses
          (store_id,expense_date,category,vendor,description,amount_cents,created_by)
         values ($1,$2,$3,$4,$5,$6,$7)
         returning *`,
        [
          request.storeId, body.expenseDate, body.category, body.vendor ?? null,
          body.description ?? null, body.amountCents, request.authUser!.userId
        ]
      );
      await audit(db, {
        storeId: request.storeId!,
        actorUserId: request.authUser!.userId,
        action: "expense.created",
        entityType: "expense",
        entityId: row.rows[0].id,
        after: row.rows[0]
      });
      return row.rows[0];
    });
    reply.code(201).send(result);
  });
}
