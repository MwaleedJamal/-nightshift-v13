import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { tx } from "../db.js";
import { requireRole } from "../plugins/auth.js";
import { processReturn } from "../domain/returns.js";

const schema = z.object({
  saleId: z.string().uuid(),
  restock: z.boolean().default(true),
  reason: z.string().max(500).optional(),
  items: z.array(z.object({
    saleItemId: z.string().uuid(),
    quantity: z.number().int().positive()
  })).min(1)
});

export async function returnRoutes(app: FastifyInstance) {
  app.post("/v1/returns", { preHandler: [app.authenticate, requireRole("cashier")] }, async (request) => {
    const body = schema.parse(request.body);
    return tx(db => processReturn(db, {
      storeId: request.storeId!,
      actorUserId: request.authUser!.userId,
      ...body
    }));
  });
}
