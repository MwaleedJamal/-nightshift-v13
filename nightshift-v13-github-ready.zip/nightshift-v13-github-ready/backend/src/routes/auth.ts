import type { FastifyInstance } from "fastify";
import argon2 from "argon2";
import { z } from "zod";
import { pool } from "../db.js";
import { AppError } from "../lib/errors.js";

const registerSchema = z.object({
  email: z.email(),
  password: z.string().min(10),
  displayName: z.string().min(1).max(120)
});
const loginSchema = z.object({
  email: z.email(),
  password: z.string().min(1)
});

export async function authRoutes(app: FastifyInstance) {
  app.post("/v1/auth/register", async (request, reply) => {
    const body = registerSchema.parse(request.body);
    const exists = await pool.query(`select id from users where lower(email)=lower($1)`, [body.email]);
    if (exists.rows[0]) throw new AppError(409, "Email already registered");

    const hash = await argon2.hash(body.password);
    const user = await pool.query(
      `insert into users (email, display_name, password_hash) values (lower($1),$2,$3)
       returning id,email,display_name`,
      [body.email, body.displayName, hash]
    );

    const row = user.rows[0];
    const token = app.jwt.sign({ sub: row.id, email: row.email }, { expiresIn: "12h" });
    reply.code(201).send({ token, user: row });
  });

  app.post("/v1/auth/login", async (request) => {
    const body = loginSchema.parse(request.body);
    const user = await pool.query(
      `select id,email,display_name,password_hash from users where lower(email)=lower($1) and active=true`,
      [body.email]
    );
    const row = user.rows[0];
    if (!row || !(await argon2.verify(row.password_hash, body.password))) {
      throw new AppError(401, "Invalid email or password");
    }
    const token = app.jwt.sign({ sub: row.id, email: row.email }, { expiresIn: "12h" });
    return { token, user: { id: row.id, email: row.email, displayName: row.display_name } };
  });
}
