import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { pool, tx } from "../db.js";
import { requireRole } from "../plugins/auth.js";
import { checkout } from "../domain/sales.js";
import { claimIdempotency, completeIdempotency } from "../domain/idempotency.js";
import { AppError } from "../lib/errors.js";
import { actionGateway } from "../control/action-gateway.js";

const checkoutSchema = z.object({
  items: z.array(z.object({
    variantId: z.string().uuid(),
    quantity: z.number().int().positive().max(1000),
    lineDiscountCents: z.number().int().nonnegative().default(0)
  })).min(1),
  cartDiscountCents: z.number().int().nonnegative().default(0),
  paymentMethod: z.enum(["cash","card","apple_pay","cash_app","venmo","zelle"]),
  paymentStatus: z.enum(["pending","captured"]).default("captured"),
  paymentReference: z.string().max(200).nullable().optional()
});

export async function salesRoutes(app: FastifyInstance) {
  app.get("/v1/sales", { preHandler: [app.authenticate, requireRole("viewer")] }, async (request) => {
    const result = await pool.query(
      `select s.id,s.sale_number,s.subtotal_cents,s.discount_cents,s.tax_cents,s.total_cents,s.status,s.created_at,
              coalesce(json_agg(json_build_object(
                'id',si.id,'name',si.product_name_snapshot,'sku',si.sku_snapshot,'quantity',si.quantity,
                'returnedQuantity',si.returned_quantity,'lineTotalCents',si.line_total_cents
              ) order by si.id) filter (where si.id is not null),'[]') as items
       from sales s
       left join sale_items si on si.sale_id=s.id and si.store_id=s.store_id
       where s.store_id=$1
       group by s.id
       order by s.created_at desc
       limit 500`,
      [request.storeId]
    );
    return { sales: result.rows };
  });

  app.post("/v1/sales/checkout", { preHandler: [app.authenticate, requireRole("cashier")] }, async (request, reply) => {
    const key = String(request.headers["idempotency-key"] ?? "");
    if (!key) throw new AppError(400, "Idempotency-Key header is required", "IDEMPOTENCY_REQUIRED");
    const body = checkoutSchema.parse(request.body);

    const response = await tx(async db => {
      const claim = await claimIdempotency(db, request.storeId!, key, "sales.checkout");
      if (claim.replay) return claim.replay;

      const result = await actionGateway(
        db,
        {
          storeId: request.storeId!,
          actorUserId: request.authUser!.userId,
          role: request.role!,
          desiredOutcome: "Complete customer purchase without overselling inventory",
          actionType: "sale.checkout",
          actionPayload: body,
          evidenceState: "VERIFIED",
          evidenceType: "live_inventory_and_payment_intent",
          evidence: { itemCount: body.items.length, paymentMethod: body.paymentMethod },
          provenance: { source: "nightshift-pos", generatedAt: new Date().toISOString() },
          stateSnapshot: { requestedItems: body.items },
          idempotencyKey: key
        },
        async () => checkout(db, {
          storeId: request.storeId!,
          actorUserId: request.authUser!.userId,
          items: body.items,
          cartDiscountCents: body.cartDiscountCents,
          paymentMethod: body.paymentMethod,
          paymentStatus: body.paymentStatus,
          paymentReference: body.paymentReference
        })
      );

      await completeIdempotency(db, request.storeId!, key, "sales.checkout", result);
      return result;
    });

    reply.send(response);
  });
}
