
import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { pool, tx } from "../db.js";
import { requireRole } from "../plugins/auth.js";
import { recommendVintagePrice } from "../vintage/pricing-engine.js";
import { createDecisionSession } from "../control/decision-service.js";

const signalSchema = z.object({
  identityConfidence: z.number().min(0).max(1),
  rarity: z.number().min(-1).max(1),
  wearCharacter: z.number().min(-1).max(1),
  culturalDesirability: z.number().min(-1).max(1),
  damageRisk: z.number().min(0).max(1),
  provenance: z.number().min(-1).max(1),

  materialIdentityConfidence: z.number().min(0).max(1).optional(),
  materialHistoricalValue: z.number().min(-1).max(1).optional(),
  materialRarity: z.number().min(-1).max(1).optional(),
  materialCollectorDemand: z.number().min(-1).max(1).optional(),
  materialAgeCharacter: z.number().min(-1).max(1).optional(),
  materialFailureRisk: z.number().min(0).max(1).optional(),
  materialEvidenceState: z.enum([
    "VERIFIED","PARTIAL","UNKNOWN_UNVERIFIED","CONTRADICTED"
  ]).optional()
});

const recommendSchema = z.object({
  variantId: z.string().uuid(),
  signals: signalSchema
});

export async function pricingRoutes(app: FastifyInstance) {
  app.post(
    "/v1/pricing/recommend",
    { preHandler: [app.authenticate, requireRole("manager")] },
    async (request) => {
      const body = recommendSchema.parse(request.body);

      const comps = await pool.query(
        `select source_name,listing_type,price_cents,match_score,observed_at
         from price_comparables
         where store_id=$1 and variant_id=$2
         order by observed_at desc
         limit 500`,
        [request.storeId,body.variantId]
      );

      const recommendation = recommendVintagePrice(
        comps.rows.map(r => ({
          source: r.source_name,
          listingType: r.listing_type,
          priceCents: Number(r.price_cents),
          matchScore: Number(r.match_score),
          observedAt: new Date(r.observed_at)
        })),
        body.signals
      );

      return tx(async db => {
        const evidence = await db.query(
          `insert into evidence_sets
           (store_id,evidence_type,state,confidence,provenance_json,evidence_json)
           values ($1,'vintage_market_comparables',$2,$3,$4,$5)
           returning id`,
          [
            request.storeId,
            recommendation.confidence >= 0.72 ? "VERIFIED" : recommendation.confidence >= 0.45 ? "PARTIAL" : "UNKNOWN_UNVERIFIED",
            recommendation.confidence,
            { engine:"nightshift-vintage-pricing-v1" },
            { comparableCount: comps.rows.length, evidence: recommendation.evidence }
          ]
        );

        const decision = await createDecisionSession(db, {
          storeId: request.storeId!,
          actorUserId: request.authUser!.userId,
          role: request.role!,
          desiredOutcome: "Price vintage garment according to current market evidence and vintage-specific value signals",
          candidateAction: "pricing.applyRecommendation",
          actionPayload: {
            variantId: body.variantId,
            targetCents: recommendation.targetCents
          },
          evidenceState: recommendation.confidence >= 0.72 ? "VERIFIED" : recommendation.confidence >= 0.45 ? "PARTIAL" : "UNKNOWN_UNVERIFIED",
          evidenceType: "vintage_market_comparables",
          evidence: recommendation.evidence,
          provenance: { engine:"nightshift-vintage-pricing-v1" },
          requestedMode: "HUMAN_REVIEW",
          stateSnapshot: { signals: body.signals, recommendation }
        });

        const row = await db.query(
          `insert into price_recommendations
           (store_id,variant_id,decision_session_id,evidence_set_id,
            quick_sale_cents,target_cents,collector_ask_cents,floor_cents,confidence,
            rarity_premium_pct,wear_character_premium_pct,cultural_premium_pct,
            material_history_premium_pct,material_failure_penalty_pct,
            damage_penalty_pct,reasoning_json,source_summary_json)
           values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17)
           returning *`,
          [
            request.storeId,body.variantId,decision.id,evidence.rows[0].id,
            recommendation.quickSaleCents,recommendation.targetCents,
            recommendation.collectorAskCents,recommendation.floorCents,
            recommendation.confidence,
            recommendation.adjustments.rarityPremiumPct,
            recommendation.adjustments.wearCharacterPremiumPct,
            recommendation.adjustments.culturalPremiumPct,
            recommendation.adjustments.materialHistoryPremiumPct,
            recommendation.adjustments.materialFailurePenaltyPct,
            recommendation.adjustments.damagePenaltyPct,
            recommendation.reasoning,
            recommendation.evidence
          ]
        );

        return {
          recommendation: row.rows[0],
          reasoning: recommendation.reasoning,
          mode: decision.mode
        };
      });
    }
  );

  app.get(
    "/v1/pricing/:variantId/history",
    { preHandler: [app.authenticate, requireRole("viewer")] },
    async (request) => {
      const variantId = (request.params as { variantId:string }).variantId;
      const result = await pool.query(
        `select * from price_recommendations
         where store_id=$1 and variant_id=$2
         order by created_at desc limit 50`,
        [request.storeId,variantId]
      );
      return { recommendations: result.rows };
    }
  );
}
