import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { pool,tx } from "../db.js";
import { requireRole } from "../plugins/auth.js";
import { createGarment,setGarmentStatus } from "../domain/garments.js";

const createSchema=z.object({
  displayName:z.string().max(160).nullable().optional(),
  brand:z.string().max(120).nullable().optional(),
  category:z.string().max(80).nullable().optional(),
  acquisitionCostCents:z.number().int().nonnegative().default(0),
  sourceName:z.string().max(160).nullable().optional(),
  acquiredAt:z.string().datetime().nullable().optional()
});

const priceSchema=z.object({
  ownerPriceCents:z.number().int().nonnegative(),
  recommendationId:z.string().uuid().nullable().optional(),
  note:z.string().max(500).optional()
});

export async function garmentRoutes(app:FastifyInstance) {
  app.get(
    "/v1/garments",
    {preHandler:[app.authenticate,requireRole("viewer")]},
    async request=>{
      const q=request.query as Record<string,string|undefined>;
      const args:any[]=[request.storeId];
      const where=["g.store_id=$1"];
      let i=2;

      if (q.status) {
        where.push(`g.status=$${i++}`);
        args.push(q.status);
      }
      if (q.brand) {
        where.push(`lower(g.brand)=lower($${i++})`);
        args.push(q.brand);
      }
      if (q.category) {
        where.push(`lower(g.category)=lower($${i++})`);
        args.push(q.category);
      }
      if (q.search) {
        where.push(`(
          g.display_name ilike $${i}
          or g.garment_sku ilike $${i}
          or g.barcode ilike $${i}
          or g.brand ilike $${i}
        )`);
        args.push(`%${q.search}%`);
        i++;
      }

      const sortMap:Record<string,string>={
        newest:"g.created_at desc",
        price_high:"g.owner_price_cents desc nulls last",
        price_low:"g.owner_price_cents asc nulls last",
        collector:"s.collector_score desc",
        move_fast:"s.fast_move_score desc",
        stale:"s.stale_score desc",
        research:"s.research_priority_score desc"
      };
      const order=sortMap[q.sort ?? ""] ?? "g.updated_at desc";

      const result=await pool.query(
        `select g.*,s.collector_score,s.fast_move_score,s.rarity_score,
                s.margin_score,s.stale_score,s.research_priority_score
         from garments g
         left join garment_sort_scores s
           on s.garment_id=g.id and s.store_id=g.store_id
         where ${where.join(" and ")}
         order by ${order}
         limit 500`,
        args
      );
      return {garments:result.rows};
    }
  );

  app.post(
    "/v1/garments",
    {preHandler:[app.authenticate,requireRole("manager")]},
    async (request,reply)=>{
      const body=createSchema.parse(request.body);
      const garment=await tx(db=>createGarment(db,{
        storeId:request.storeId!,
        actorUserId:request.authUser!.userId,
        displayName:body.displayName,
        brand:body.brand,
        category:body.category,
        acquisitionCostCents:body.acquisitionCostCents,
        sourceName:body.sourceName,
        acquiredAt:body.acquiredAt ? new Date(body.acquiredAt) : null
      }));
      reply.code(201).send(garment);
    }
  );

  app.get(
    "/v1/garments/by-barcode/:barcode",
    {preHandler:[app.authenticate,requireRole("viewer")]},
    async request=>{
      const barcode=(request.params as {barcode:string}).barcode;
      const result=await pool.query(
        `select g.*,s.collector_score,s.fast_move_score,s.rarity_score,
                s.margin_score,s.stale_score,s.research_priority_score
         from garments g
         left join garment_sort_scores s on s.garment_id=g.id
         where g.store_id=$1 and g.barcode=$2`,
        [request.storeId,barcode]
      );
      return result.rows[0] ?? {error:"not_found"};
    }
  );

  app.get(
    "/v1/garments/:id",
    {preHandler:[app.authenticate,requireRole("viewer")]},
    async request=>{
      const id=(request.params as {id:string}).id;
      const [garment,events,media,identity,prices]=await Promise.all([
        pool.query(`select * from garments where id=$1 and store_id=$2`,[id,request.storeId]),
        pool.query(`select * from garment_events where garment_id=$1 and store_id=$2 order by id desc limit 200`,[id,request.storeId]),
        pool.query(`select * from garment_media where garment_id=$1 and store_id=$2 order by position`,[id,request.storeId]),
        pool.query(`select * from garment_identity_versions where garment_id=$1 and store_id=$2 order by version desc limit 10`,[id,request.storeId]),
        pool.query(`select * from price_recommendations where garment_id=$1 and store_id=$2 order by created_at desc limit 20`,[id,request.storeId])
      ]);
      if (!garment.rows[0]) return {error:"not_found"};
      return {
        garment:garment.rows[0],
        events:events.rows,
        media:media.rows,
        identityVersions:identity.rows,
        priceHistory:prices.rows
      };
    }
  );

  app.post(
    "/v1/garments/:id/price",
    {preHandler:[app.authenticate,requireRole("manager")]},
    async request=>{
      const id=(request.params as {id:string}).id;
      const body=priceSchema.parse(request.body);
      return tx(async db=>{
        const updated=await db.query(
          `update garments
           set owner_price_cents=$3,
               price_recommendation_id=$4,
               status=case
                 when status in ('inbox','identified','researched') then 'priced'
                 else status
               end,
               updated_at=now()
           where id=$1 and store_id=$2
           returning *`,
          [id,request.storeId,body.ownerPriceCents,body.recommendationId ?? null]
        );
        if (!updated.rows[0]) throw new Error("Garment not found");

        await db.query(
          `insert into garment_price_decisions
           (store_id,garment_id,recommendation_id,chosen_price_cents,chosen_by,decision_note)
           values($1,$2,$3,$4,$5,$6)`,
          [
            request.storeId,id,body.recommendationId ?? null,
            body.ownerPriceCents,request.authUser!.userId,body.note ?? null
          ]
        );

        await db.query(
          `insert into garment_events
           (store_id,garment_id,event_type,payload_json,actor_user_id)
           values ($1,$2,'garment.price_chosen',$3,$4)`,
          [
            request.storeId,id,
            {
              ownerPriceCents:body.ownerPriceCents,
              recommendationId:body.recommendationId ?? null
            },
            request.authUser!.userId
          ]
        );
        return updated.rows[0];
      });
    }
  );

  app.post(
    "/v1/garments/:id/ready",
    {preHandler:[app.authenticate,requireRole("manager")]},
    async request=>{
      const id=(request.params as {id:string}).id;
      return tx(db=>setGarmentStatus(db,{
        storeId:request.storeId!,
        garmentId:id,
        status:"ready",
        actorUserId:request.authUser!.userId
      }));
    }
  );
}
