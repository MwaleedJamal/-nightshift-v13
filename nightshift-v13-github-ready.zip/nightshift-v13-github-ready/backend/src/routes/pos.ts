import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { tx,pool } from "../db.js";
import { requireRole } from "../plugins/auth.js";
import { actionGateway } from "../control/action-gateway.js";

const checkoutSchema=z.object({
  garmentIds:z.array(z.string().uuid()).min(1).max(100),
  paymentMethod:z.enum(["cash","card","apple_pay","cash_app","venmo","zelle"]),
  paymentStatus:z.enum(["pending","captured"]).default("captured"),
  paymentReference:z.string().max(200).nullable().optional()
});

export async function posRoutes(app:FastifyInstance) {
  app.get(
    "/v1/pos/scan/:barcode",
    {preHandler:[app.authenticate,requireRole("cashier")]},
    async request=>{
      const barcode=(request.params as {barcode:string}).barcode;
      const result=await pool.query(
        `select id,garment_sku,barcode,display_name,brand,category,
                owner_price_cents,status
         from garments
         where store_id=$1 and barcode=$2`,
        [request.storeId,barcode]
      );
      const g=result.rows[0];
      if (!g) return {error:"not_found"};
      if (g.status!=="ready") return {
        error:"not_sellable",
        status:g.status,
        garment:g
      };
      return {garment:g};
    }
  );

  app.post(
    "/v1/pos/checkout",
    {preHandler:[app.authenticate,requireRole("cashier")]},
    async (request)=>{
      const body=checkoutSchema.parse(request.body);
      const idempotencyKey=String(request.headers["idempotency-key"] ?? "");
      if (!idempotencyKey) throw new Error("Idempotency-Key required");

      return tx(async db=>actionGateway(
        db,
        {
          storeId:request.storeId!,
          actorUserId:request.authUser!.userId,
          role:request.role!,
          desiredOutcome:"Ring out unique vintage garments without double-selling",
          actionType:"sale.checkout",
          actionPayload:body,
          evidenceState:"VERIFIED",
          evidenceType:"live_garment_state",
          evidence:{garmentIds:body.garmentIds},
          provenance:{source:"nightshift-register"},
          stateSnapshot:{garmentIds:body.garmentIds},
          idempotencyKey
        },
        async ()=>{
          const ids=[...new Set(body.garmentIds)].sort();

          const garments=[];
          for (const id of ids) {
            const result=await db.query(
              `select id,garment_sku,display_name,owner_price_cents,
                      acquisition_cost_cents,status,variant_id
               from garments
               where id=$1 and store_id=$2
               for update`,
              [id,request.storeId]
            );
            const g=result.rows[0];
            if (!g) throw new Error("Garment not found");
            if (g.status!=="ready") {
              throw new Error(`${g.garment_sku} is ${g.status}, not ready`);
            }
            if (g.owner_price_cents == null) {
              throw new Error(`${g.garment_sku} has no owner price`);
            }
            garments.push(g);
          }

          const subtotal=garments.reduce(
            (s,g)=>s+Number(g.owner_price_cents),0
          );

          const settings=await db.query(
            `select tax_basis_points from store_settings where store_id=$1`,
            [request.storeId]
          );
          const taxBps=Number(settings.rows[0]?.tax_basis_points ?? 825);
          const tax=Math.round(subtotal*taxBps/10000);
          const total=subtotal+tax;

          const sale=await db.query(
            `insert into sales
             (store_id,sale_number,subtotal_cents,discount_cents,tax_cents,
              total_cents,status,created_by)
             values($1,next_sale_number($1),$2,0,$3,$4,'completed',$5)
             returning id,sale_number,created_at`,
            [request.storeId,subtotal,tax,total,request.authUser!.userId]
          );
          const s=sale.rows[0];

          for (const g of garments) {
            await db.query(
              `insert into sale_items
               (sale_id,store_id,variant_id,garment_id,sku_snapshot,
                product_name_snapshot,variant_label_snapshot,
                unit_price_cents,unit_cost_cents,quantity,discount_cents,
                line_total_cents)
               values($1,$2,$3,$4,$5,$6,'',$7,$8,1,0,$7)`,
              [
                s.id,request.storeId,g.variant_id,g.id,g.garment_sku,
                g.display_name ?? g.garment_sku,
                g.owner_price_cents,g.acquisition_cost_cents
              ]
            );

            await db.query(
              `update garments
               set status='sold',updated_at=now()
               where id=$1`,
              [g.id]
            );

            await db.query(
              `insert into garment_events
               (store_id,garment_id,event_type,payload_json,actor_user_id)
               values($1,$2,'garment.sold',$3,$4)`,
              [
                request.storeId,g.id,
                {saleId:s.id,saleNumber:s.sale_number,priceCents:g.owner_price_cents},
                request.authUser!.userId
              ]
            );
          }

          await db.query(
            `insert into payments
             (store_id,sale_id,method,status,amount_cents,external_reference)
             values($1,$2,$3,$4,$5,$6)`,
            [
              request.storeId,s.id,body.paymentMethod,
              body.paymentStatus,total,body.paymentReference ?? null
            ]
          );

          return {
            saleId:s.id,
            saleNumber:s.sale_number,
            subtotalCents:subtotal,
            taxCents:tax,
            totalCents:total,
            garmentCount:garments.length,
            createdAt:s.created_at
          };
        }
      ));
    }
  );
}
