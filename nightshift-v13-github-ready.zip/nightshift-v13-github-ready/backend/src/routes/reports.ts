import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { pool } from "../db.js";
import { requireRole } from "../plugins/auth.js";

const querySchema = z.object({
  from: z.string().optional(),
  to: z.string().optional()
});

export async function reportRoutes(app: FastifyInstance) {
  app.get("/v1/reports/summary", { preHandler: [app.authenticate, requireRole("manager")] }, async (request) => {
    const q = querySchema.parse(request.query);
    const from = q.from ? new Date(q.from) : new Date(Date.now() - 30*86400_000);
    const to = q.to ? new Date(q.to) : new Date();

    const [sales, cogs, expenses, inventory, payments] = await Promise.all([
      pool.query(
        `select coalesce(sum(total_cents),0)::bigint as revenue_cents,
                count(*)::int as sales
         from sales
         where store_id=$1 and created_at between $2 and $3 and status <> 'void'`,
        [request.storeId, from, to]
      ),
      pool.query(
        `select coalesce(sum(si.unit_cost_cents * greatest(si.quantity-si.returned_quantity,0)),0)::bigint as cogs_cents
         from sale_items si join sales s on s.id=si.sale_id and s.store_id=si.store_id
         where si.store_id=$1 and s.created_at between $2 and $3 and s.status <> 'void'`,
        [request.storeId, from, to]
      ),
      pool.query(
        `select coalesce(sum(amount_cents),0)::bigint as expense_cents
         from expenses where store_id=$1 and expense_date between $2::date and $3::date`,
        [request.storeId, from, to]
      ),
      pool.query(
        `select coalesce(sum(b.quantity*v.cost_cents),0)::bigint as inventory_cost_cents,
                coalesce(sum(b.quantity*v.price_cents),0)::bigint as inventory_retail_cents,
                coalesce(sum(b.quantity),0)::int as units,
                count(*) filter (where b.quantity <= v.low_stock_threshold)::int as low_stock
         from inventory_balances b
         join variants v on v.id=b.variant_id and v.store_id=b.store_id
         where b.store_id=$1 and v.active=true`,
        [request.storeId]
      ),
      pool.query(
        `select p.method, count(*)::int as payments, coalesce(sum(p.amount_cents),0)::bigint as amount_cents
         from payments p join sales s on s.id=p.sale_id and s.store_id=p.store_id
         where p.store_id=$1 and s.created_at between $2 and $3
         group by p.method order by amount_cents desc`,
        [request.storeId, from, to]
      )
    ]);

    const revenue = Number(sales.rows[0].revenue_cents);
    const cogsCents = Number(cogs.rows[0].cogs_cents);
    const expenseCents = Number(expenses.rows[0].expense_cents);
    const grossProfitCents = revenue - cogsCents;

    return {
      from, to,
      revenueCents: revenue,
      sales: Number(sales.rows[0].sales),
      cogsCents,
      grossProfitCents,
      expenseCents,
      netProfitCents: grossProfitCents - expenseCents,
      inventory: {
        costCents: Number(inventory.rows[0].inventory_cost_cents),
        retailCents: Number(inventory.rows[0].inventory_retail_cents),
        units: Number(inventory.rows[0].units),
        lowStock: Number(inventory.rows[0].low_stock)
      },
      paymentMix: payments.rows
    };
  });
}
