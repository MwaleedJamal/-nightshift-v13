import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { pool, tx } from "../db.js";
import { requireRole } from "../plugins/auth.js";
import { createDecisionSession } from "../control/decision-service.js";

const schema = z.object({
  desiredOutcome: z.string().min(1).max(500),
  candidateAction: z.string().min(1).max(160),
  actionPayload: z.unknown(),
  evidenceState: z.enum(["VERIFIED","PARTIAL","UNKNOWN_UNVERIFIED","CONTRADICTED"]),
  evidenceType: z.string().max(120).optional(),
  evidence: z.unknown().optional(),
  provenance: z.unknown().optional(),
  requestedMode: z.enum(["RECOMMEND","HUMAN_REVIEW","SHADOW","ABSTAIN","BLOCK"]).optional(),
  stateSnapshot: z.unknown()
});

export async function decisionRoutes(app: FastifyInstance) {
  app.post(
    "/v1/decisions/evaluate",
    { preHandler: [app.authenticate, requireRole("viewer")] },
    async (request) => {
      const body = schema.parse(request.body);
      return tx(db => createDecisionSession(db, {
        storeId: request.storeId!,
        actorUserId: request.authUser!.userId,
        role: request.role!,
        ...body
      }));
    }
  );

  app.get(
    "/v1/decisions/:id",
    { preHandler: [app.authenticate, requireRole("viewer")] },
    async (request) => {
      const id = (request.params as { id: string }).id;
      const result = await pool.query(
        `select ds.*,e.state as evidence_state,e.provenance_json,
                pp.policy_key,pp.version as policy_version
         from decision_sessions ds
         left join evidence_sets e on e.id=ds.evidence_set_id
         left join policy_packs pp on pp.id=ds.policy_pack_id
         where ds.id=$1 and ds.store_id=$2`,
        [id,request.storeId]
      );
      return result.rows[0] ?? { error: "not_found" };
    }
  );
}
