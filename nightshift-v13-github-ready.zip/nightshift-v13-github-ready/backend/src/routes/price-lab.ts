import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { pool,tx } from "../db.js";
import { requireRole } from "../plugins/auth.js";
import { priceResearchQueue } from "../lib/queue.js";
import { recommendVintagePrice } from "../vintage/pricing-engine.js";
import { calibratePriceMultiplier } from "../intelligence/price-learning.js";
import { computeGarmentSortScores } from "../intelligence/sorting-engine.js";
import { createDecisionSession } from "../control/decision-service.js";

const profileSchema=z.object({
  identityConfidence:z.number().min(0).max(1),
  rarity:z.number().min(-1).max(1),
  wearCharacter:z.number().min(-1).max(1),
  culturalDesirability:z.number().min(-1).max(1),
  damageRisk:z.number().min(0).max(1),
  provenance:z.number().min(-1).max(1),

  materialIdentityConfidence:z.number().min(0).max(1).default(0),
  materialHistoricalValue:z.number().min(-1).max(1).default(0),
  materialRarity:z.number().min(-1).max(1).default(0),
  materialCollectorDemand:z.number().min(-1).max(1).default(0),
  materialAgeCharacter:z.number().min(-1).max(1).default(0),
  materialFailureRisk:z.number().min(0).max(1).default(0),
  materialEvidenceState:z.enum([
    "VERIFIED","PARTIAL","UNKNOWN_UNVERIFIED","CONTRADICTED"
  ]).default("UNKNOWN_UNVERIFIED"),

  identity:z.unknown().default({}),
  material:z.unknown().default({}),
  wear:z.unknown().default({})
});

export async function priceLabRoutes(app:FastifyInstance) {
  app.put(
    "/v1/garments/:id/intelligence",
    {preHandler:[app.authenticate,requireRole("manager")]},
    async request=>{
      const garmentId=(request.params as {id:string}).id;
      const body=profileSchema.parse(request.body);

      const result=await pool.query(
        `insert into garment_intelligence_profiles
         (garment_id,store_id,identity_confidence,rarity_score,
          wear_character_score,cultural_desirability_score,damage_risk,
          provenance_score,material_identity_confidence,
          material_historical_value,material_rarity,
          material_collector_demand,material_age_character,
          material_failure_risk,material_evidence_state,
          identity_json,material_json,wear_json)
         values
         ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18)
         on conflict(garment_id) do update set
           identity_confidence=excluded.identity_confidence,
           rarity_score=excluded.rarity_score,
           wear_character_score=excluded.wear_character_score,
           cultural_desirability_score=excluded.cultural_desirability_score,
           damage_risk=excluded.damage_risk,
           provenance_score=excluded.provenance_score,
           material_identity_confidence=excluded.material_identity_confidence,
           material_historical_value=excluded.material_historical_value,
           material_rarity=excluded.material_rarity,
           material_collector_demand=excluded.material_collector_demand,
           material_age_character=excluded.material_age_character,
           material_failure_risk=excluded.material_failure_risk,
           material_evidence_state=excluded.material_evidence_state,
           identity_json=excluded.identity_json,
           material_json=excluded.material_json,
           wear_json=excluded.wear_json,
           updated_at=now()
         returning *`,
        [
          garmentId,request.storeId,body.identityConfidence,body.rarity,
          body.wearCharacter,body.culturalDesirability,body.damageRisk,
          body.provenance,body.materialIdentityConfidence,
          body.materialHistoricalValue,body.materialRarity,
          body.materialCollectorDemand,body.materialAgeCharacter,
          body.materialFailureRisk,body.materialEvidenceState,
          body.identity,body.material,body.wear
        ]
      );
      return result.rows[0];
    }
  );

  app.post(
    "/v1/garments/:id/research-prices",
    {preHandler:[app.authenticate,requireRole("manager")]},
    async (request,reply)=>{
      const garmentId=(request.params as {id:string}).id;

      const row=await pool.query(
        `select g.id,g.store_id,g.brand,g.category,g.display_name,
                p.identity_confidence,p.identity_json,p.material_json
         from garments g
         left join garment_intelligence_profiles p
           on p.garment_id=g.id and p.store_id=g.store_id
         where g.id=$1 and g.store_id=$2`,
        [garmentId,request.storeId]
      );
      if (!row.rows[0]) return reply.code(404).send({error:"not_found"});

      const g=row.rows[0];
      const identity=g.identity_json ?? {};

      const run=await pool.query(
        `insert into comp_search_runs
         (store_id,garment_id,status,query_plan_json)
         values($1,$2,'queued',$3)
         returning id,status,created_at`,
        [
          request.storeId,garmentId,
          {
            brand:identity.brand ?? g.brand,
            model:identity.model ?? null,
            garmentType:identity.garmentType ?? g.category,
            eraLabel:identity.eraLabel ?? null,
            tagGeneration:identity.tagGeneration ?? null,
            graphicOrLicense:identity.graphicOrLicense ?? null,
            color:identity.color ?? null,
            materialTerms:Array.isArray(g.material_json?.searchTerms)
              ? g.material_json.searchTerms
              : []
          }
        ]
      );

      await priceResearchQueue.add(
        "research-garment",
        {searchRunId:run.rows[0].id},
        {
          jobId:run.rows[0].id,
          attempts:3,
          backoff:{type:"exponential",delay:1500},
          removeOnComplete:1000,
          removeOnFail:1000
        }
      );

      reply.code(202).send(run.rows[0]);
    }
  );

  app.get(
    "/v1/garments/:id/price-lab",
    {preHandler:[app.authenticate,requireRole("manager")]},
    async request=>{
      const garmentId=(request.params as {id:string}).id;

      const [garment,profile,comps,recs,runs,decisions]=await Promise.all([
        pool.query(`select * from garments where id=$1 and store_id=$2`,[garmentId,request.storeId]),
        pool.query(`select * from garment_intelligence_profiles where garment_id=$1 and store_id=$2`,[garmentId,request.storeId]),
        pool.query(
          `select * from price_comparables
           where garment_id=$1 and store_id=$2
           order by listing_type='sold' desc,match_score desc,observed_at desc
           limit 250`,
          [garmentId,request.storeId]
        ),
        pool.query(
          `select * from price_recommendations
           where garment_id=$1 and store_id=$2
           order by created_at desc limit 25`,
          [garmentId,request.storeId]
        ),
        pool.query(
          `select * from comp_search_runs
           where garment_id=$1 and store_id=$2
           order by created_at desc limit 10`,
          [garmentId,request.storeId]
        ),
        pool.query(
          `select * from garment_price_decisions
           where garment_id=$1 and store_id=$2
           order by created_at desc limit 25`,
          [garmentId,request.storeId]
        )
      ]);

      if (!garment.rows[0]) return {error:"not_found"};
      return {
        garment:garment.rows[0],
        intelligence:profile.rows[0] ?? null,
        comparables:comps.rows,
        recommendations:recs.rows,
        researchRuns:runs.rows,
        ownerDecisions:decisions.rows
      };
    }
  );

  app.post(
    "/v1/garments/:id/recommend-price",
    {preHandler:[app.authenticate,requireRole("manager")]},
    async request=>{
      const garmentId=(request.params as {id:string}).id;

      return tx(async db=>{
        const garment=await db.query(
          `select * from garments where id=$1 and store_id=$2 for update`,
          [garmentId,request.storeId]
        );
        const g=garment.rows[0];
        if (!g) throw new Error("Garment not found");

        const profile=await db.query(
          `select * from garment_intelligence_profiles
           where garment_id=$1 and store_id=$2`,
          [garmentId,request.storeId]
        );
        const p=profile.rows[0];
        if (!p) throw new Error("Garment intelligence profile missing");

        const comps=await db.query(
          `select source_name,listing_type,normalized_price_cents,
                  match_score,observed_at,rejected_reason
           from price_comparables
           where garment_id=$1 and store_id=$2
             and rejected_reason is null
             and normalized_price_cents is not null`,
          [garmentId,request.storeId]
        );

        const base=recommendVintagePrice(
          comps.rows.map(r=>({
            source:r.source_name,
            listingType:r.listing_type,
            priceCents:Number(r.normalized_price_cents),
            matchScore:Number(r.match_score),
            observedAt:new Date(r.observed_at)
          })),
          {
            identityConfidence:Number(p.identity_confidence),
            rarity:Number(p.rarity_score),
            wearCharacter:Number(p.wear_character_score),
            culturalDesirability:Number(p.cultural_desirability_score),
            damageRisk:Number(p.damage_risk),
            provenance:Number(p.provenance_score),

            materialIdentityConfidence:Number(p.material_identity_confidence),
            materialHistoricalValue:Number(p.material_historical_value),
            materialRarity:Number(p.material_rarity),
            materialCollectorDemand:Number(p.material_collector_demand),
            materialAgeCharacter:Number(p.material_age_character),
            materialFailureRisk:Number(p.material_failure_risk),
            materialEvidenceState:p.material_evidence_state
          }
        );

        const segmentKey=[
          (g.brand ?? "unknown").toLowerCase(),
          (g.category ?? "unknown").toLowerCase(),
          (p.identity_json?.eraLabel ?? "unknown").toLowerCase()
        ].join("|");

        const outcomes=await db.query(
          `select rpo.listed_price_cents,rpo.sold_price_cents,
                  rpo.days_to_sell,pr.target_cents
           from realized_price_outcomes rpo
           join price_recommendations pr on pr.id=rpo.recommendation_id
           join garments gg on gg.id=rpo.garment_id
           left join garment_intelligence_profiles gip on gip.garment_id=gg.id
           where rpo.store_id=$1
             and lower(coalesce(gg.brand,'unknown'))=$2
             and lower(coalesce(gg.category,'unknown'))=$3
             and lower(coalesce(gip.identity_json->>'eraLabel','unknown'))=$4
             and rpo.sold_price_cents is not null
           limit 250`,
          [
            request.storeId,
            (g.brand ?? "unknown").toLowerCase(),
            (g.category ?? "unknown").toLowerCase(),
            (p.identity_json?.eraLabel ?? "unknown").toLowerCase()
          ]
        );

        const calibration=calibratePriceMultiplier(
          outcomes.rows.map(r=>({
            recommendedTargetCents:Number(r.target_cents),
            chosenPriceCents:Number(r.listed_price_cents ?? r.target_cents),
            soldPriceCents:Number(r.sold_price_cents),
            daysToSell:Number(r.days_to_sell ?? 0)
          }))
        );

        const adjusted={
          quickSaleCents:Math.round(base.quickSaleCents*calibration.multiplier),
          targetCents:Math.round(base.targetCents*calibration.multiplier),
          collectorAskCents:Math.round(base.collectorAskCents*calibration.multiplier),
          floorCents:Math.round(base.floorCents*calibration.multiplier)
        };

        const latestRun=await db.query(
          `select hostile_data_flags_json
           from comp_search_runs
           where garment_id=$1 and store_id=$2
           order by created_at desc limit 1`,
          [garmentId,request.storeId]
        );
        const flags=latestRun.rows[0]?.hostile_data_flags_json ?? [];

        const critical=Array.isArray(flags) &&
          flags.some((f:any)=>f?.severity==="critical");

        const evidenceState=
          critical || base.confidence<.45
            ? "UNKNOWN_UNVERIFIED"
            : base.confidence<.72
              ? "PARTIAL"
              : "VERIFIED";

        const decision=await createDecisionSession(db,{
          storeId:request.storeId!,
          actorUserId:request.authUser!.userId,
          role:request.role!,
          desiredOutcome:"Price this exact vintage garment using defensible global evidence and store learning",
          candidateAction:"pricing.applyRecommendation",
          actionPayload:{garmentId,targetCents:adjusted.targetCents},
          evidenceState,
          evidenceType:"global_vintage_comparables",
          evidence:{
            comparableCount:comps.rows.length,
            hostileDataFlags:flags,
            calibration
          },
          provenance:{
            engine:"nightshift-v13",
            segmentKey
          },
          requestedMode:"HUMAN_REVIEW",
          stateSnapshot:{garment:g,profile:p,base,adjusted,calibration}
        });

        const inserted=await db.query(
          `insert into price_recommendations
           (store_id,garment_id,decision_session_id,evidence_set_id,
            quick_sale_cents,target_cents,collector_ask_cents,floor_cents,
            confidence,rarity_premium_pct,wear_character_premium_pct,
            cultural_premium_pct,material_history_premium_pct,
            material_failure_penalty_pct,damage_penalty_pct,
            calibration_multiplier,hostile_data_flags_json,
            reasoning_json,source_summary_json)
           values
           ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19)
           returning *`,
          [
            request.storeId,garmentId,decision.id,decision.evidence_set_id,
            adjusted.quickSaleCents,adjusted.targetCents,
            adjusted.collectorAskCents,adjusted.floorCents,
            base.confidence,
            base.adjustments.rarityPremiumPct,
            base.adjustments.wearCharacterPremiumPct,
            base.adjustments.culturalPremiumPct,
            base.adjustments.materialHistoryPremiumPct,
            base.adjustments.materialFailurePenaltyPct,
            base.adjustments.damagePenaltyPct,
            calibration.multiplier,
            flags,
            [
              ...base.reasoning,
              calibration.sampleSize>0
                ? `Store calibration x${calibration.multiplier.toFixed(3)} from ${calibration.sampleSize} realized sales.`
                : "No store-specific price calibration yet."
            ],
            {
              ...base.evidence,
              hostileDataFlags:flags,
              calibration
            }
          ]
        );

        const rec=inserted.rows[0];

        const scores=computeGarmentSortScores({
          confidence:Number(base.confidence),
          targetPriceCents:Number(rec.target_cents),
          acquisitionCostCents:Number(g.acquisition_cost_cents),
          rarity:Math.max(0,Number(p.rarity_score)),
          culturalDemand:Math.max(0,Number(p.cultural_desirability_score)),
          materialHistoricalValue:Math.max(0,Number(p.material_historical_value)),
          wearCharacter:Number(p.wear_character_score),
          daysInInventory:Math.max(
            0,
            (Date.now()-new Date(g.created_at).getTime())/86_400_000
          ),
          comparableCount:comps.rows.length,
          soldComparableCount:comps.rows.filter(
            r=>r.listing_type==="sold"
          ).length
        });

        await db.query(
          `update garment_sort_scores
           set collector_score=$3,fast_move_score=$4,rarity_score=$5,
               margin_score=$6,stale_score=$7,research_priority_score=$8,
               updated_at=now()
           where garment_id=$1 and store_id=$2`,
          [
            garmentId,request.storeId,scores.collectorScore,
            scores.fastMoveScore,scores.rarityScore,scores.marginScore,
            scores.staleScore,scores.researchPriorityScore
          ]
        );

        return {
          recommendation:rec,
          reasoning:rec.reasoning_json,
          mode:decision.mode,
          hostileDataFlags:flags,
          calibration
        };
      });
    }
  );
}
