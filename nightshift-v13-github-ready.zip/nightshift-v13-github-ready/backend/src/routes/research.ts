import type { FastifyInstance } from "fastify";
import { z } from "zod";
import { pool } from "../db.js";
import { requireRole } from "../plugins/auth.js";
import { researchQueue } from "../lib/queue.js";

const schema = z.object({
  imageKey: z.string().min(1),
  variantId: z.string().uuid().nullable().optional(),
  notes: z.string().max(1000).optional()
});

export async function researchRoutes(app: FastifyInstance) {
  app.post("/v1/research", { preHandler: [app.authenticate, requireRole("cashier")] }, async (request, reply) => {
    const body = schema.parse(request.body);
    if (!body.imageKey.startsWith(`stores/${request.storeId}/`)) throw new Error("Invalid image key");

    const result = await pool.query(
      `insert into research_jobs (store_id,variant_id,image_key,status,notes,created_by)
       values ($1,$2,$3,'queued',$4,$5)
       returning id,status,created_at`,
      [request.storeId, body.variantId ?? null, body.imageKey, body.notes ?? null, request.authUser!.userId]
    );
    await researchQueue.add("analyze", { researchJobId: result.rows[0].id }, {
      jobId: result.rows[0].id,
      attempts: 3,
      backoff: { type: "exponential", delay: 1500 },
      removeOnComplete: 1000,
      removeOnFail: 1000
    });
    reply.code(202).send(result.rows[0]);
  });

  app.get("/v1/research/:id", { preHandler: [app.authenticate, requireRole("viewer")] }, async (request) => {
    const id = (request.params as { id: string }).id;
    const result = await pool.query(
      `select id,status,result_json,error_message,created_at,started_at,completed_at
       from research_jobs where id=$1 and store_id=$2`,
      [id, request.storeId]
    );
    if (!result.rows[0]) return { error: "not_found" };
    return result.rows[0];
  });
}
