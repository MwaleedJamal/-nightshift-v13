export type GarmentSearchIdentity = {
  brand?: string | null;
  model?: string | null;
  garmentType?: string | null;
  eraLabel?: string | null;
  tagGeneration?: string | null;
  graphicOrLicense?: string | null;
  materialTerms?: string[];
  color?: string | null;
};

const clean = (value?: string | null) => (value ?? "").trim();

export function buildCompQueryPlan(identity: GarmentSearchIdentity): Array<{
  tier: "exact" | "era" | "material" | "broad";
  query: string;
}> {
  const core = [
    clean(identity.brand),
    clean(identity.model),
    clean(identity.garmentType),
    clean(identity.graphicOrLicense)
  ].filter(Boolean);

  const exact = [
    ...core,
    clean(identity.tagGeneration),
    clean(identity.eraLabel),
    clean(identity.color)
  ].filter(Boolean).join(" ");

  const era = [
    ...core,
    clean(identity.eraLabel),
    clean(identity.tagGeneration)
  ].filter(Boolean).join(" ");

  const material = [
    ...core,
    ...(identity.materialTerms ?? []).slice(0,3)
  ].filter(Boolean).join(" ");

  const broad = core.join(" ");

  const out = [
    { tier:"exact" as const, query:exact },
    { tier:"era" as const, query:era },
    { tier:"material" as const, query:material },
    { tier:"broad" as const, query:broad }
  ].filter(x => x.query.length > 2);

  const seen = new Set<string>();
  return out.filter(x => {
    const key = x.query.toLowerCase().replace(/\s+/g," ").trim();
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}
