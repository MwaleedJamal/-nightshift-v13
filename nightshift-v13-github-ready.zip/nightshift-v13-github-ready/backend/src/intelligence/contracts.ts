export type IntelligenceRecommendation<TAction = unknown> = {
  recommendationId: string;
  modelKey: string;
  modelVersion: number;
  generatedAt: string;
  desiredOutcome: string;
  candidateAction: string;
  action: TAction;
  confidence: number;
  uncertainty?: {
    lower?: number;
    upper?: number;
    notes?: string[];
  };
  evidence: {
    state: "VERIFIED" | "PARTIAL" | "UNKNOWN_UNVERIFIED" | "CONTRADICTED";
    sources: Array<{
      type: string;
      ref: string;
      observedAt?: string;
      freshnessSeconds?: number;
    }>;
  };
  explanation: {
    summary: string;
    factors: Array<{ name: string; contribution?: number; detail?: string }>;
  };
};

/**
 * Intelligence produces proposals only.
 * Never call database mutation functions from Intelligence Plane code.
 */
export interface IntelligenceProvider {
  recommend(input: unknown): Promise<IntelligenceRecommendation>;
}
