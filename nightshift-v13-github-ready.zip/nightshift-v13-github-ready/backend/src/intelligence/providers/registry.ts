import { config } from "../../config.js";
import { WebhookCompSearchProvider } from "./webhook-provider.js";
import type { CompSearchProvider } from "./types.js";

type ProviderConfig = {
  key:string;
  endpoint:string;
  token?:string;
};

export function configuredCompProviders():CompSearchProvider[] {
  let raw:unknown=[];
  try {
    raw=JSON.parse(config.COMP_SEARCH_PROVIDERS_JSON);
  } catch {
    throw new Error("COMP_SEARCH_PROVIDERS_JSON is invalid JSON");
  }

  if (!Array.isArray(raw)) {
    throw new Error("COMP_SEARCH_PROVIDERS_JSON must be an array");
  }

  return raw
    .filter((x):x is ProviderConfig =>
      !!x &&
      typeof x === "object" &&
      typeof (x as any).key === "string" &&
      typeof (x as any).endpoint === "string"
    )
    .map(x => new WebhookCompSearchProvider(x.key,x.endpoint,x.token));
}

export function convertConfiguredCurrency(
  minor:number,
  from:string,
  to:string
):number {
  if (from===to) return minor;

  let rates:Record<string,number>;
  try {
    rates=JSON.parse(config.FX_RATES_JSON) as Record<string,number>;
  } catch {
    throw new Error("FX_RATES_JSON is invalid JSON");
  }

  const fromRate=rates[from];
  const toRate=rates[to];

  if (!fromRate || !toRate) {
    throw new Error(`Missing FX rate for ${from} or ${to}`);
  }

  // Rates are units per USD.
  const usd=minor/fromRate;
  return usd*toRate;
}
