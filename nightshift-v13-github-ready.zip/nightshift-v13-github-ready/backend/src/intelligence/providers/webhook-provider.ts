import type { CompSearchProvider, SearchCandidate } from "./types.js";

export class WebhookCompSearchProvider implements CompSearchProvider {
  constructor(
    public key:string,
    private endpoint:string,
    private token?:string
  ) {}

  async search(input:{
    query:string;
    tier:"exact"|"era"|"material"|"broad";
    limit:number;
  }):Promise<SearchCandidate[]> {
    const response = await fetch(this.endpoint,{
      method:"POST",
      headers:{
        "content-type":"application/json",
        ...(this.token ? { authorization:`Bearer ${this.token}` } : {})
      },
      body:JSON.stringify(input)
    });

    if (!response.ok) {
      throw new Error(`${this.key} search provider returned ${response.status}`);
    }

    const body = await response.json() as { candidates?:SearchCandidate[] };
    return Array.isArray(body.candidates) ? body.candidates : [];
  }
}
