export type SearchCandidate = {
  sourceName: string;
  sourceListingId?: string | null;
  sourceUrl?: string | null;
  title: string;
  listingType: "sold" | "active" | "archive" | "retail" | "other";
  priceMinor: number;
  currency: string;
  observedAt: string;
  soldAt?: string | null;
  attributes?: Record<string,unknown>;
  raw?: unknown;
};

export interface CompSearchProvider {
  key: string;
  search(input: {
    query: string;
    tier: "exact" | "era" | "material" | "broad";
    limit: number;
  }): Promise<SearchCandidate[]>;
}
