export type GarmentSortInput = {
  confidence:number;
  targetPriceCents:number;
  acquisitionCostCents:number;
  rarity:number;
  culturalDemand:number;
  materialHistoricalValue:number;
  wearCharacter:number;
  daysInInventory:number;
  comparableCount:number;
  soldComparableCount:number;
};

const clamp=(v:number,lo=0,hi=1)=>Math.min(hi,Math.max(lo,v));

export function computeGarmentSortScores(x:GarmentSortInput) {
  const margin=x.targetPriceCents>0
    ? (x.targetPriceCents-x.acquisitionCostCents)/x.targetPriceCents
    : 0;

  const collectorScore=clamp(
    x.rarity*.30+
    x.culturalDemand*.23+
    x.materialHistoricalValue*.18+
    Math.max(0,x.wearCharacter)*.10+
    x.confidence*.19
  );

  const fastMoveScore=clamp(
    x.culturalDemand*.35+
    (1-x.rarity*.25)*.10+
    clamp(margin)*.20+
    x.confidence*.20+
    clamp(x.soldComparableCount/8)*.15
  );

  const staleScore=clamp(
    (x.daysInInventory-30)/150
  );

  const researchPriorityScore=clamp(
    (1-x.confidence)*.35+
    (x.comparableCount<5 ? .25 : 0)+
    (x.soldComparableCount<2 ? .25 : 0)+
    Math.max(x.rarity,x.materialHistoricalValue)*.15
  );

  return {
    collectorScore,
    fastMoveScore,
    rarityScore:clamp(x.rarity),
    marginScore:clamp(margin),
    staleScore,
    researchPriorityScore
  };
}
