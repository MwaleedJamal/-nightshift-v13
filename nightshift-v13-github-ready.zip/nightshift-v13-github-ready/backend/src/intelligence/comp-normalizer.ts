import crypto from "node:crypto";
import type { SearchCandidate } from "./providers/types.js";

export type NormalizedCandidate = SearchCandidate & {
  canonicalKey:string;
  normalizedPriceCents:number;
  normalizedCurrency:string;
  duplicateGroupKey:string;
  staleScore:number;
};

const normalizeText = (s:string) =>
  s.toLowerCase()
   .replace(/[^\p{L}\p{N}\s]/gu," ")
   .replace(/\s+/g," ")
   .trim();

export function canonicalListingKey(c:SearchCandidate):string {
  if (c.sourceListingId) return `${c.sourceName}:${c.sourceListingId}`;
  if (c.sourceUrl) {
    try {
      const u = new URL(c.sourceUrl);
      u.search = "";
      u.hash = "";
      return `${c.sourceName}:${u.toString()}`;
    } catch {}
  }
  return `${c.sourceName}:${normalizeText(c.title)}:${c.priceMinor}:${c.currency}`;
}

export function duplicateGroupKey(c:SearchCandidate):string {
  const title = normalizeText(c.title)
    .split(" ")
    .filter(x => x.length > 2)
    .sort()
    .slice(0,12)
    .join(" ");
  const bucket = Math.round(c.priceMinor / 500);
  return crypto.createHash("sha1")
    .update(`${title}|${bucket}|${c.currency}`)
    .digest("hex")
    .slice(0,20);
}

export function staleScore(observedAt:string):number {
  const ms = Date.now() - new Date(observedAt).getTime();
  const days = Math.max(0,ms / 86_400_000);
  if (days <= 30) return 0;
  if (days <= 90) return 0.1;
  if (days <= 180) return 0.25;
  if (days <= 365) return 0.45;
  return 0.72;
}

export function normalizeCandidates(
  candidates:SearchCandidate[],
  convert:(minor:number,from:string,to:string)=>number,
  targetCurrency="USD"
):NormalizedCandidate[] {
  return candidates.map(c => ({
    ...c,
    canonicalKey:canonicalListingKey(c),
    normalizedPriceCents:Math.max(
      0,
      Math.round(convert(c.priceMinor,c.currency,targetCurrency))
    ),
    normalizedCurrency:targetCurrency,
    duplicateGroupKey:duplicateGroupKey(c),
    staleScore:staleScore(c.observedAt)
  }));
}

export function dedupeCandidates(
  rows:NormalizedCandidate[]
):NormalizedCandidate[] {
  const byCanonical = new Map<string,NormalizedCandidate>();

  for (const row of rows) {
    const existing = byCanonical.get(row.canonicalKey);
    if (!existing || new Date(row.observedAt) > new Date(existing.observedAt)) {
      byCanonical.set(row.canonicalKey,row);
    }
  }

  // Cross-source near-duplicates: keep the stronger evidence form.
  const typeRank = { sold:5, active:4, archive:3, retail:2, other:1 } as const;
  const byGroup = new Map<string,NormalizedCandidate>();

  for (const row of byCanonical.values()) {
    const existing = byGroup.get(row.duplicateGroupKey);
    if (
      !existing ||
      typeRank[row.listingType] > typeRank[existing.listingType] ||
      (
        typeRank[row.listingType] === typeRank[existing.listingType] &&
        row.staleScore < existing.staleScore
      )
    ) {
      byGroup.set(row.duplicateGroupKey,row);
    }
  }

  return [...byGroup.values()];
}
