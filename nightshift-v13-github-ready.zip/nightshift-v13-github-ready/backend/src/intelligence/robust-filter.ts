export function robustPriceFilter<T extends { normalizedPriceCents:number }>(
  rows:T[]
):{accepted:T[];rejected:Array<{row:T;reason:string}>} {
  if (rows.length < 5) return {accepted:rows,rejected:[]};

  const prices=rows.map(r=>r.normalizedPriceCents).sort((a,b)=>a-b);
  const median=(a:number[]) => {
    const mid=Math.floor(a.length/2);
    return a.length%2 ? a[mid]! : (a[mid-1]!+a[mid]!)/2;
  };

  const m=median(prices);
  const deviations=prices.map(x=>Math.abs(x-m)).sort((a,b)=>a-b);
  const mad=median(deviations);

  if (mad === 0) return {accepted:rows,rejected:[]};

  const accepted:T[]=[];
  const rejected:Array<{row:T;reason:string}>=[];

  for (const row of rows) {
    const robustZ=0.6745*(row.normalizedPriceCents-m)/mad;
    if (Math.abs(robustZ)>5.2) {
      rejected.push({row,reason:`robust price outlier z=${robustZ.toFixed(2)}`});
    } else {
      accepted.push(row);
    }
  }
  return {accepted,rejected};
}
