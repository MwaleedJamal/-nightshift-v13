export type SaleOutcome = {
  recommendedTargetCents:number;
  chosenPriceCents:number;
  soldPriceCents:number;
  daysToSell:number;
};

const clamp=(v:number,lo:number,hi:number)=>Math.min(hi,Math.max(lo,v));

/**
 * Lightweight shrinkage calibrator.
 *
 * It intentionally does not overfit tiny segments.
 * At zero samples multiplier stays 1.
 * The empirical multiplier receives more weight as observations accumulate.
 */
export function calibratePriceMultiplier(
  outcomes:SaleOutcome[]
):{
  multiplier:number;
  confidence:number;
  sampleSize:number;
  medianDaysToSell:number|null;
  realizedToRecommendedRatio:number|null;
} {
  const usable=outcomes.filter(
    x=>x.recommendedTargetCents>0 && x.soldPriceCents>0 && x.daysToSell>=0
  );
  if (!usable.length) {
    return {
      multiplier:1,
      confidence:0,
      sampleSize:0,
      medianDaysToSell:null,
      realizedToRecommendedRatio:null
    };
  }

  const ratios=usable
    .map(x=>x.soldPriceCents/x.recommendedTargetCents)
    .sort((a,b)=>a-b);

  const mid=Math.floor(ratios.length/2);
  const medianRatio=ratios.length%2
    ? ratios[mid]!
    : (ratios[mid-1]!+ratios[mid]!)/2;

  const days=usable.map(x=>x.daysToSell).sort((a,b)=>a-b);
  const medianDays=days.length%2
    ? days[Math.floor(days.length/2)]!
    : (days[days.length/2-1]!+days[days.length/2]!)/2;

  // Prior strength of 12 prevents the first few sales from swinging pricing.
  const empiricalWeight=usable.length/(usable.length+12);
  const multiplier=clamp(
    1*(1-empiricalWeight)+medianRatio*empiricalWeight,
    0.82,
    1.22
  );

  return {
    multiplier,
    confidence:clamp(usable.length/40,0,0.95),
    sampleSize:usable.length,
    medianDaysToSell:medianDays,
    realizedToRecommendedRatio:medianRatio
  };
}
