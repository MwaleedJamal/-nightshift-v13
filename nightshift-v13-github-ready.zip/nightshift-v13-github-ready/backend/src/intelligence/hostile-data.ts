import type { NormalizedCandidate } from "./comp-normalizer.js";

export type HostileDataFlag = {
  code:
    | "SPARSE_SOLD_EVIDENCE"
    | "ACTIVE_ASK_DOMINANCE"
    | "DUPLICATE_PRESSURE"
    | "PRICE_OUTLIER_PRESSURE"
    | "STALE_EVIDENCE"
    | "CURRENCY_COVERAGE_GAP"
    | "IDENTITY_UNCERTAIN";
  severity:"info"|"warning"|"critical";
  detail:string;
};

function median(values:number[]):number {
  if (!values.length) return 0;
  const s=[...values].sort((a,b)=>a-b);
  const mid=Math.floor(s.length/2);
  return s.length%2 ? s[mid]! : (s[mid-1]!+s[mid]!)/2;
}

export function detectHostileData(
  input:{
    rawCount:number;
    normalized:NormalizedCandidate[];
    identityConfidence:number;
  }
):HostileDataFlag[] {
  const flags:HostileDataFlag[]=[];
  const sold=input.normalized.filter(x=>x.listingType==="sold");
  const active=input.normalized.filter(x=>x.listingType==="active");

  if (sold.length < 3) {
    flags.push({
      code:"SPARSE_SOLD_EVIDENCE",
      severity:sold.length === 0 ? "critical" : "warning",
      detail:`Only ${sold.length} sold comparable(s).`
    });
  }

  if (active.length >= Math.max(6,sold.length*4)) {
    flags.push({
      code:"ACTIVE_ASK_DOMINANCE",
      severity:"warning",
      detail:"Active asking prices heavily outnumber realized-sale evidence."
    });
  }

  if (input.rawCount > 0 && input.normalized.length / input.rawCount < 0.55) {
    flags.push({
      code:"DUPLICATE_PRESSURE",
      severity:"warning",
      detail:"A large share of search results collapsed as duplicates."
    });
  }

  const prices=input.normalized.map(x=>x.normalizedPriceCents).filter(x=>x>0);
  const m=median(prices);
  const deviations=prices.map(x=>Math.abs(x-m));
  const mad=median(deviations);

  if (mad > 0) {
    const outliers=prices.filter(x=>Math.abs(x-m) > mad*4.5);
    if (outliers.length / prices.length > 0.2) {
      flags.push({
        code:"PRICE_OUTLIER_PRESSURE",
        severity:"warning",
        detail:`${outliers.length} extreme price outlier(s) detected.`
      });
    }
  }

  if (
    input.normalized.length > 0 &&
    input.normalized.filter(x=>x.staleScore>=0.45).length / input.normalized.length > 0.4
  ) {
    flags.push({
      code:"STALE_EVIDENCE",
      severity:"warning",
      detail:"More than 40% of accepted evidence is over one year old."
    });
  }

  if (input.identityConfidence < 0.62) {
    flags.push({
      code:"IDENTITY_UNCERTAIN",
      severity:"critical",
      detail:"Garment identity confidence is too weak for aggressive pricing inference."
    });
  }

  return flags;
}
