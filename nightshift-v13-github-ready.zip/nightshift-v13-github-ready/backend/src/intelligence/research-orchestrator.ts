import type { CompSearchProvider } from "./providers/types.js";
import { buildCompQueryPlan, type GarmentSearchIdentity } from "./query-planner.js";
import { normalizeCandidates,dedupeCandidates } from "./comp-normalizer.js";
import { robustPriceFilter } from "./robust-filter.js";
import { detectHostileData } from "./hostile-data.js";

export async function runCompResearch(
  input:{
    identity:GarmentSearchIdentity;
    identityConfidence:number;
    providers:CompSearchProvider[];
    convertCurrency:(minor:number,from:string,to:string)=>number;
    targetCurrency:string;
  }
) {
  const plan=buildCompQueryPlan(input.identity);
  const raw=[] as Awaited<ReturnType<CompSearchProvider["search"]>>;

  const providerSummary:Record<string,{ok:boolean;count:number;error?:string}>={};

  for (const provider of input.providers) {
    let providerCount=0;
    try {
      for (const query of plan) {
        const rows=await provider.search({
          query:query.query,
          tier:query.tier,
          limit:40
        });
        raw.push(...rows);
        providerCount+=rows.length;
      }
      providerSummary[provider.key]={ok:true,count:providerCount};
    } catch (error) {
      providerSummary[provider.key]={
        ok:false,
        count:providerCount,
        error:error instanceof Error ? error.message : String(error)
      };
    }
  }

  const normalized=normalizeCandidates(
    raw,input.convertCurrency,input.targetCurrency
  );
  const deduped=dedupeCandidates(normalized);
  const filtered=robustPriceFilter(deduped);

  const flags=detectHostileData({
    rawCount:raw.length,
    normalized:filtered.accepted,
    identityConfidence:input.identityConfidence
  });

  return {
    plan,
    providerSummary,
    rawCount:raw.length,
    normalizedCount:normalized.length,
    dedupedCount:deduped.length,
    accepted:filtered.accepted,
    rejected:filtered.rejected,
    flags
  };
}
