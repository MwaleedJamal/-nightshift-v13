import type { FastifyRequest } from "fastify";

export type Role = "owner" | "admin" | "manager" | "cashier" | "viewer";

export type AuthUser = {
  userId: string;
  email: string;
};

declare module "fastify" {
  interface FastifyRequest {
    authUser?: AuthUser;
    storeId?: string;
    role?: Role;
  }

  interface FastifyInstance {
    authenticate: (request: FastifyRequest) => Promise<void>;
  }
}
