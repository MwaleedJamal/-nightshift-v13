import Fastify from "fastify";
import cors from "@fastify/cors";
import swagger from "@fastify/swagger";
import swaggerUi from "@fastify/swagger-ui";
import { Registry, collectDefaultMetrics } from "prom-client";
import { ZodError } from "zod";
import { corsOrigins } from "./config.js";
import { authPlugin } from "./plugins/auth.js";
import { AppError } from "./lib/errors.js";
import { authRoutes } from "./routes/auth.js";
import { inventoryRoutes } from "./routes/inventory.js";
import { salesRoutes } from "./routes/sales.js";
import { returnRoutes } from "./routes/returns.js";
import { mediaRoutes } from "./routes/media.js";
import { researchRoutes } from "./routes/research.js";
import { reportRoutes } from "./routes/reports.js";
import { expenseRoutes } from "./routes/expenses.js";
import { decisionRoutes } from "./routes/decisions.js";
import { memoryRoutes } from "./routes/memory.js";
import { pricingRoutes } from "./routes/pricing.js";
import { garmentRoutes } from "./routes/garments.js";
import { posRoutes } from "./routes/pos.js";
import { priceLabRoutes } from "./routes/price-lab.js";

export async function buildApp() {
  const app = Fastify({ logger: true, trustProxy: true });

  await app.register(cors, {
    origin(origin, cb) {
      if (!origin || corsOrigins.includes(origin)) return cb(null, true);
      cb(new Error("Origin not allowed"), false);
    }
  });

  await app.register(swagger, {
    openapi: {
      info: { title: "NIGHTSHIFT API", version: "1.0.0" }
    }
  });
  await app.register(swaggerUi, { routePrefix: "/docs" });
  await authPlugin(app);

  const registry = new Registry();
  collectDefaultMetrics({ register: registry });

  app.get("/health", async () => ({ ok: true, service: "nightshift-api", now: new Date().toISOString() }));
  app.get("/metrics", async (_req, reply) => {
    reply.header("content-type", registry.contentType);
    return registry.metrics();
  });

  await authRoutes(app);
  await inventoryRoutes(app);
  await salesRoutes(app);
  await returnRoutes(app);
  await mediaRoutes(app);
  await researchRoutes(app);
  await reportRoutes(app);
  await expenseRoutes(app);
  await decisionRoutes(app);
  await memoryRoutes(app);
  await pricingRoutes(app);
  await garmentRoutes(app);
  await posRoutes(app);
  await priceLabRoutes(app);

  app.setErrorHandler((error, _request, reply) => {
    if (error instanceof ZodError) {
      return reply.code(400).send({ error: "VALIDATION_ERROR", issues: error.issues });
    }
    if (error instanceof AppError) {
      return reply.code(error.statusCode).send({ error: error.code, message: error.message });
    }
    app.log.error(error);
    reply.code(500).send({ error: "INTERNAL_ERROR", message: "Unexpected server error" });
  });

  return app;
}
