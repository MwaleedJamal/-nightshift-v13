import { z } from "zod";

const schema = z.object({
  NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
  PORT: z.coerce.number().int().positive().default(8787),
  HOST: z.string().default("0.0.0.0"),
  DATABASE_URL: z.string().min(1),
  REDIS_URL: z.string().min(1),
  JWT_SECRET: z.string().min(32),
  CORS_ORIGIN: z.string().default("http://localhost:3000"),
  MINIO_ENDPOINT: z.string().default("localhost"),
  MINIO_PORT: z.coerce.number().int().positive().default(9000),
  MINIO_USE_SSL: z.string().transform(v => v === "true").default("false"),
  MINIO_ACCESS_KEY: z.string().min(1),
  MINIO_SECRET_KEY: z.string().min(1),
  MINIO_BUCKET: z.string().default("nightshift-media"),
  RESEARCH_PROVIDER: z.enum(["stub", "webhook"]).default("stub"),
  RESEARCH_WEBHOOK_URL: z.string().optional().default(""),
  COMP_SEARCH_PROVIDERS_JSON: z.string().default("[]"),
  FX_RATES_JSON: z.string().default("{\"USD\":1}")
});

export const config = schema.parse(process.env);
export const corsOrigins = config.CORS_ORIGIN.split(",").map(x => x.trim()).filter(Boolean);
