import { z } from "zod";

export const offlineCommandSchema = z.object({
  commandId: z.string().min(8).max(200),
  deviceId: z.string().min(1).max(200),
  occurredAt: z.string().datetime(),
  commandType: z.string().min(1).max(160),
  payload: z.unknown(),
  clientTruthVersion: z.string().nullable().optional()
});

export type OfflineCommand = z.infer<typeof offlineCommandSchema>;

/**
 * Offline commands are proposals. They become authoritative only after
 * server-side write-time revalidation against current truth and policy.
 */
