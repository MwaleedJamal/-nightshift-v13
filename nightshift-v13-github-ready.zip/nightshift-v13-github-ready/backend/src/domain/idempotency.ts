import type { DbClient } from "../db.js";
import { AppError } from "../lib/errors.js";

export async function claimIdempotency(
  db: DbClient,
  storeId: string,
  key: string,
  command: string
): Promise<{ replay?: unknown }> {
  const inserted = await db.query(
    `insert into idempotency_keys (store_id, idempotency_key, command, status)
     values ($1,$2,$3,'in_progress')
     on conflict do nothing
     returning id`,
    [storeId, key, command]
  );

  if (inserted.rowCount === 1) return {};

  const existing = await db.query(
    `select status, response_json from idempotency_keys
     where store_id=$1 and idempotency_key=$2 and command=$3
     for update`,
    [storeId, key, command]
  );

  if (!existing.rows[0]) throw new AppError(409, "Idempotency key conflict");
  if (existing.rows[0].status === "completed") {
    return { replay: existing.rows[0].response_json };
  }
  throw new AppError(409, "Command with this idempotency key is already in progress", "IDEMPOTENCY_IN_PROGRESS");
}

export async function completeIdempotency(
  db: DbClient,
  storeId: string,
  key: string,
  command: string,
  response: unknown
) {
  await db.query(
    `update idempotency_keys
     set status='completed', response_json=$4, completed_at=now()
     where store_id=$1 and idempotency_key=$2 and command=$3`,
    [storeId, key, command, response]
  );
}
