import type { DbClient } from "../db.js";
import { allocateGarmentIdentity } from "./barcode.js";
import { audit } from "../lib/audit.js";
import { emitOutbox } from "../lib/outbox.js";

export async function createGarment(
  db: DbClient,
  input: {
    storeId: string;
    actorUserId: string;
    displayName?: string | null;
    brand?: string | null;
    category?: string | null;
    acquisitionCostCents?: number;
    sourceName?: string | null;
    acquiredAt?: Date | null;
  }
) {
  const identity = await allocateGarmentIdentity(db,input.storeId);

  const { rows } = await db.query(
    `insert into garments
      (store_id,garment_sku,barcode,status,display_name,brand,category,
       acquisition_cost_cents,source_name,acquired_at,created_by)
     values ($1,$2,$3,'inbox',$4,$5,$6,$7,$8,$9,$10)
     returning *`,
    [
      input.storeId,
      identity.garmentSku,
      identity.barcode,
      input.displayName ?? null,
      input.brand ?? null,
      input.category ?? null,
      input.acquisitionCostCents ?? 0,
      input.sourceName ?? null,
      input.acquiredAt ?? null,
      input.actorUserId
    ]
  );

  const garment = rows[0];

  await db.query(
    `insert into garment_sort_scores(store_id,garment_id)
     values($1,$2)`,
    [input.storeId,garment.id]
  );

  await db.query(
    `insert into garment_events(store_id,garment_id,event_type,payload_json,actor_user_id)
     values($1,$2,'garment.created',$3,$4)`,
    [input.storeId,garment.id,{ barcode:identity.barcode, sku:identity.garmentSku },input.actorUserId]
  );

  await audit(db,{
    storeId:input.storeId,
    actorUserId:input.actorUserId,
    action:"garment.created",
    entityType:"garment",
    entityId:garment.id,
    after:garment
  });

  await emitOutbox(
    db,input.storeId,"garment.created","garment",garment.id,
    { garmentId:garment.id,barcode:garment.barcode,garmentSku:garment.garment_sku }
  );

  return garment;
}

export async function setGarmentStatus(
  db: DbClient,
  input: {
    storeId:string;
    garmentId:string;
    status:"inbox"|"identified"|"researched"|"priced"|"ready"|"reserved"|"sold"|"archived";
    actorUserId:string;
    payload?:unknown;
  }
) {
  const { rows } = await db.query(
    `update garments
     set status=$3,updated_at=now()
     where id=$1 and store_id=$2
     returning *`,
    [input.garmentId,input.storeId,input.status]
  );

  if (!rows[0]) throw new Error("Garment not found");

  await db.query(
    `insert into garment_events(store_id,garment_id,event_type,payload_json,actor_user_id)
     values($1,$2,$3,$4,$5)`,
    [
      input.storeId,input.garmentId,`garment.${input.status}`,
      input.payload ?? {},input.actorUserId
    ]
  );
  return rows[0];
}
