import type { DbClient } from "../db.js";

function checksum12(payload12: string): number {
  if (!/^\d{12}$/.test(payload12)) throw new Error("EAN payload must be 12 digits");
  let sum = 0;
  for (let i = 0; i < 12; i++) {
    const n = Number(payload12[i]);
    sum += i % 2 === 0 ? n : n * 3;
  }
  return (10 - (sum % 10)) % 10;
}

export function ean13FromPayload(payload12: string): string {
  return payload12 + String(checksum12(payload12));
}

/**
 * NIGHTSHIFT uses an internal/restricted-distribution EAN namespace.
 *
 * Layout:
 *   29 + 3-digit store namespace + 7-digit store sequence + check digit
 *
 * The database allocates namespace and sequence under row lock, so two intake
 * devices cannot generate the same barcode.
 */
export async function allocateGarmentIdentity(
  db: DbClient,
  storeId: string
): Promise<{ barcode: string; garmentSku: string; sequence: number }> {
  await db.query(
    `insert into store_barcode_namespaces(store_id)
     values($1)
     on conflict(store_id) do nothing`,
    [storeId]
  );

  const { rows } = await db.query(
    `select namespace_id,next_sequence
     from store_barcode_namespaces
     where store_id=$1
     for update`,
    [storeId]
  );

  const namespace = Number(rows[0].namespace_id);
  const sequence = Number(rows[0].next_sequence);

  if (namespace > 999) throw new Error("Barcode namespace exhausted");
  if (sequence > 9_999_999) throw new Error("Store barcode sequence exhausted");

  await db.query(
    `update store_barcode_namespaces
     set next_sequence=next_sequence+1
     where store_id=$1`,
    [storeId]
  );

  const payload =
    "29" +
    String(namespace).padStart(3,"0") +
    String(sequence).padStart(7,"0");

  return {
    barcode: ean13FromPayload(payload),
    garmentSku: `NS-${String(namespace).padStart(3,"0")}-${String(sequence).padStart(7,"0")}`,
    sequence
  };
}
