import type { DbClient } from "../db.js";
import { AppError } from "../lib/errors.js";
import { appendInventoryEvent } from "./inventory.js";
import { audit } from "../lib/audit.js";
import { emitOutbox } from "../lib/outbox.js";

export async function processReturn(
  db: DbClient,
  input: {
    storeId: string;
    saleId: string;
    actorUserId: string;
    restock: boolean;
    reason?: string;
    items: Array<{ saleItemId: string; quantity: number }>;
  }
) {
  const sale = await db.query(
    `select id, total_cents, subtotal_cents, discount_cents, tax_cents, status
     from sales where id=$1 and store_id=$2 for update`,
    [input.saleId, input.storeId]
  );
  if (!sale.rows[0]) throw new AppError(404, "Sale not found");

  let refundCents = 0;
  for (const requestItem of input.items) {
    const item = await db.query(
      `select id, variant_id, quantity, returned_quantity, line_total_cents
       from sale_items where id=$1 and sale_id=$2 and store_id=$3 for update`,
      [requestItem.saleItemId, input.saleId, input.storeId]
    );
    const row = item.rows[0];
    if (!row) throw new AppError(404, "Sale item not found");
    const available = Number(row.quantity) - Number(row.returned_quantity);
    if (requestItem.quantity <= 0 || requestItem.quantity > available) {
      throw new AppError(409, `Only ${available} units are returnable`);
    }

    const unitPreTax = Number(row.line_total_cents) / Number(row.quantity);
    const saleRow = sale.rows[0];
    const cartFactor = Number(saleRow.subtotal_cents) > 0
      ? Math.max(0, (Number(saleRow.subtotal_cents) - Number(saleRow.discount_cents)) / Number(saleRow.subtotal_cents))
      : 1;
    const taxFactor = Number(saleRow.total_cents) / Math.max(1, Number(saleRow.subtotal_cents) - Number(saleRow.discount_cents));
    const amount = Math.round(unitPreTax * requestItem.quantity * cartFactor * taxFactor);
    refundCents += amount;

    const ret = await db.query(
      `insert into return_items
        (store_id, sale_id, sale_item_id, quantity, refund_cents, reason, restocked, created_by)
       values ($1,$2,$3,$4,$5,$6,$7,$8)
       returning id`,
      [
        input.storeId, input.saleId, row.id, requestItem.quantity,
        amount, input.reason ?? null, input.restock, input.actorUserId
      ]
    );

    await db.query(
      `update sale_items set returned_quantity=returned_quantity+$1 where id=$2`,
      [requestItem.quantity, row.id]
    );

    if (input.restock && row.variant_id) {
      await appendInventoryEvent(db, {
        storeId: input.storeId,
        variantId: row.variant_id,
        delta: requestItem.quantity,
        reason: "return",
        referenceType: "return_item",
        referenceId: ret.rows[0].id,
        note: input.reason,
        actorUserId: input.actorUserId
      });
    }
  }

  const remaining = await db.query(
    `select coalesce(sum(quantity-returned_quantity),0)::int as remaining
     from sale_items where sale_id=$1 and store_id=$2`,
    [input.saleId, input.storeId]
  );
  const status = Number(remaining.rows[0].remaining) === 0 ? "refunded" : "partially_refunded";
  await db.query(`update sales set status=$1 where id=$2 and store_id=$3`, [status, input.saleId, input.storeId]);

  const response = { saleId: input.saleId, refundCents, status };
  await audit(db, {
    storeId: input.storeId,
    actorUserId: input.actorUserId,
    action: "sale.returned",
    entityType: "sale",
    entityId: input.saleId,
    after: response
  });
  await emitOutbox(db, input.storeId, "sale.returned", "sale", input.saleId, response);
  return response;
}
