import type { DbClient } from "../db.js";
import { audit } from "../lib/audit.js";
import { emitOutbox } from "../lib/outbox.js";

export async function appendInventoryEvent(
  db: DbClient,
  input: {
    storeId: string;
    variantId: string;
    delta: number;
    reason: "initial" | "purchase" | "adjustment" | "sale" | "return" | "damage" | "import";
    referenceType?: string;
    referenceId?: string;
    note?: string;
    actorUserId: string | null;
  }
) {
  const { rows } = await db.query(
    `insert into inventory_events
      (store_id, variant_id, delta, reason, reference_type, reference_id, note, actor_user_id)
     values ($1,$2,$3,$4,$5,$6,$7,$8)
     returning id, created_at`,
    [
      input.storeId,
      input.variantId,
      input.delta,
      input.reason,
      input.referenceType ?? null,
      input.referenceId ?? null,
      input.note ?? null,
      input.actorUserId
    ]
  );

  await audit(db, {
    storeId: input.storeId,
    actorUserId: input.actorUserId,
    action: "inventory.event.appended",
    entityType: "variant",
    entityId: input.variantId,
    after: { delta: input.delta, reason: input.reason }
  });

  await emitOutbox(db, input.storeId, "inventory.changed", "variant", input.variantId, {
    delta: input.delta,
    reason: input.reason
  });

  return rows[0];
}
