import type { DbClient } from "../db.js";
import { AppError } from "../lib/errors.js";
import { audit } from "../lib/audit.js";
import { emitOutbox } from "../lib/outbox.js";
import { appendInventoryEvent } from "./inventory.js";

export type CheckoutInput = {
  storeId: string;
  actorUserId: string;
  items: Array<{ variantId: string; quantity: number; lineDiscountCents: number }>;
  cartDiscountCents: number;
  paymentMethod: "cash" | "card" | "apple_pay" | "cash_app" | "venmo" | "zelle";
  paymentStatus: "pending" | "captured";
  paymentReference?: string | null;
};

export async function checkout(db: DbClient, input: CheckoutInput) {
  const settings = await db.query(
    `select tax_basis_points from store_settings where store_id=$1`,
    [input.storeId]
  );
  const taxBps = Number(settings.rows[0]?.tax_basis_points ?? 825);

  const requested = [...input.items].sort((a,b) => a.variantId.localeCompare(b.variantId));
  const resolved: Array<{
    variantId: string;
    sku: string;
    productName: string;
    variantLabel: string;
    priceCents: number;
    costCents: number;
    quantity: number;
    discountCents: number;
    lineSubtotalCents: number;
  }> = [];

  for (const item of requested) {
    const q = await db.query(
      `select v.id, v.sku, v.price_cents, v.cost_cents, v.size, v.color,
              p.name, b.quantity
       from variants v
       join products p on p.id=v.product_id and p.store_id=v.store_id
       join inventory_balances b on b.variant_id=v.id and b.store_id=v.store_id
       where v.id=$1 and v.store_id=$2 and v.active=true
       for update of b`,
      [item.variantId, input.storeId]
    );
    const row = q.rows[0];
    if (!row) throw new AppError(404, "Variant not found");
    if (row.quantity < item.quantity) {
      throw new AppError(409, `${row.name} only has ${row.quantity} left`, "INSUFFICIENT_STOCK");
    }

    const gross = Number(row.price_cents) * item.quantity;
    if (item.lineDiscountCents < 0 || item.lineDiscountCents > gross) {
      throw new AppError(400, `Invalid discount for ${row.name}`);
    }

    resolved.push({
      variantId: row.id,
      sku: row.sku,
      productName: row.name,
      variantLabel: [row.size, row.color].filter(Boolean).join(" / "),
      priceCents: Number(row.price_cents),
      costCents: Number(row.cost_cents),
      quantity: item.quantity,
      discountCents: item.lineDiscountCents,
      lineSubtotalCents: gross - item.lineDiscountCents
    });
  }

  const linesSubtotal = resolved.reduce((s,x) => s + x.lineSubtotalCents, 0);
  if (input.cartDiscountCents < 0 || input.cartDiscountCents > linesSubtotal) {
    throw new AppError(400, "Invalid cart discount");
  }

  const taxableCents = linesSubtotal - input.cartDiscountCents;
  const taxCents = Math.round(taxableCents * taxBps / 10_000);
  const totalCents = taxableCents + taxCents;

  const sale = await db.query(
    `insert into sales
      (store_id, sale_number, subtotal_cents, discount_cents, tax_cents, total_cents, status, created_by)
     values ($1, next_sale_number($1), $2,$3,$4,$5,'completed',$6)
     returning id, sale_number, created_at`,
    [input.storeId, linesSubtotal, input.cartDiscountCents, taxCents, totalCents, input.actorUserId]
  );
  const saleRow = sale.rows[0];

  for (const line of resolved) {
    await db.query(
      `insert into sale_items
        (sale_id, store_id, variant_id, sku_snapshot, product_name_snapshot, variant_label_snapshot,
         unit_price_cents, unit_cost_cents, quantity, discount_cents, line_total_cents)
       values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
      [
        saleRow.id, input.storeId, line.variantId, line.sku, line.productName, line.variantLabel,
        line.priceCents, line.costCents, line.quantity, line.discountCents, line.lineSubtotalCents
      ]
    );

    await appendInventoryEvent(db, {
      storeId: input.storeId,
      variantId: line.variantId,
      delta: -line.quantity,
      reason: "sale",
      referenceType: "sale",
      referenceId: saleRow.id,
      note: saleRow.sale_number,
      actorUserId: input.actorUserId
    });
  }

  await db.query(
    `insert into payments
      (store_id, sale_id, method, status, amount_cents, external_reference)
     values ($1,$2,$3,$4,$5,$6)`,
    [
      input.storeId, saleRow.id, input.paymentMethod, input.paymentStatus,
      totalCents, input.paymentReference ?? null
    ]
  );

  const response = {
    saleId: saleRow.id,
    saleNumber: saleRow.sale_number,
    subtotalCents: linesSubtotal,
    discountCents: input.cartDiscountCents,
    taxCents,
    totalCents,
    createdAt: saleRow.created_at
  };

  await audit(db, {
    storeId: input.storeId,
    actorUserId: input.actorUserId,
    action: "sale.completed",
    entityType: "sale",
    entityId: saleRow.id,
    after: response
  });

  await emitOutbox(db, input.storeId, "sale.completed", "sale", saleRow.id, response);
  return response;
}
