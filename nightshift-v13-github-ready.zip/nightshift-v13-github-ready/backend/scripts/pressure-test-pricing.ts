import { dedupeCandidates,normalizeCandidates } from "../src/intelligence/comp-normalizer.js";
import { detectHostileData } from "../src/intelligence/hostile-data.js";
import { robustPriceFilter } from "../src/intelligence/robust-filter.js";

const now=new Date().toISOString();
const old=new Date(Date.now()-500*86_400_000).toISOString();

const fixture=[
  ...Array.from({length:8},(_,i)=>({
    sourceName:"market-a",
    sourceListingId:`sold-${i}`,
    sourceUrl:`https://a.test/${i}`,
    title:"1990s Carhartt Detroit Jacket Brown Faded",
    listingType:"sold" as const,
    priceMinor:12000+i*300,
    currency:"USD",
    observedAt:now
  })),
  // duplicated syndicated listing
  {
    sourceName:"market-b",
    sourceListingId:"dup-a",
    sourceUrl:"https://b.test/1?utm_source=x",
    title:"Carhartt Detroit Jacket 90s Brown Faded",
    listingType:"active" as const,
    priceMinor:22000,
    currency:"USD",
    observedAt:now
  },
  {
    sourceName:"market-c",
    sourceListingId:"dup-b",
    sourceUrl:"https://c.test/44",
    title:"90s Brown Faded Carhartt Detroit Jacket",
    listingType:"active" as const,
    priceMinor:22000,
    currency:"USD",
    observedAt:now
  },
  // absurd outlier
  {
    sourceName:"market-x",
    sourceListingId:"outlier",
    sourceUrl:"https://x.test/o",
    title:"RARE Carhartt Detroit Jacket",
    listingType:"active" as const,
    priceMinor:999999,
    currency:"USD",
    observedAt:now
  },
  // stale
  {
    sourceName:"archive",
    sourceListingId:"old",
    sourceUrl:"https://archive.test/old",
    title:"Carhartt Detroit Jacket",
    listingType:"sold" as const,
    priceMinor:6000,
    currency:"USD",
    observedAt:old
  }
];

const normalized=normalizeCandidates(fixture,(n)=>n,"USD");
const deduped=dedupeCandidates(normalized);
const filtered=robustPriceFilter(deduped);
const flags=detectHostileData({
  rawCount:fixture.length,
  normalized:filtered.accepted,
  identityConfidence:.94
});

console.log(JSON.stringify({
  raw:fixture.length,
  deduped:deduped.length,
  accepted:filtered.accepted.length,
  rejected:filtered.rejected.map(x=>({
    title:x.row.title,
    price:x.row.normalizedPriceCents,
    reason:x.reason
  })),
  flags
},null,2));

if (filtered.accepted.some(x=>x.normalizedPriceCents===999999)) {
  throw new Error("pressure test failed: extreme outlier survived");
}
console.log("PASS: extreme outlier rejected and evidence flags produced");
