import argon2 from "argon2";
import { pool } from "../src/db.js";
import { tx } from "../src/db.js";
import { appendInventoryEvent } from "../src/domain/inventory.js";

const passwordHash = await argon2.hash("Nightshift123!");

const result = await tx(async db => {
  let user = await db.query(`select id,email from users where email='owner@nightshift.local'`);
  if (!user.rows[0]) {
    user = await db.query(
      `insert into users(email,display_name,password_hash)
       values('owner@nightshift.local','Nightshift Owner',$1)
       returning id,email`,
      [passwordHash]
    );
  }

  let store = await db.query(`select id,name from stores where slug='nightshift-demo'`);
  if (!store.rows[0]) {
    store = await db.query(
      `insert into stores(name,slug) values('NIGHTSHIFT Demo','nightshift-demo') returning id,name`
    );
    await db.query(`insert into store_settings(store_id) values($1)`, [store.rows[0].id]);
  }

  await db.query(
    `insert into memberships(store_id,user_id,role)
     values($1,$2,'owner') on conflict(store_id,user_id) do update set role='owner',active=true`,
    [store.rows[0].id, user.rows[0].id]
  );

  const count = await db.query(`select count(*)::int as n from variants where store_id=$1`, [store.rows[0].id]);
  if (Number(count.rows[0].n) === 0) {
        const realSeeds = [
      {name:"Vintage Racing Jacket",brand:"Wilson",category:"Jackets",sku:"NS-001",barcode:"2000000010014",cost:1800,price:12000,qty:3},
      {name:"Levi's 501 Denim",brand:"Levi's",category:"Denim",sku:"NS-002",barcode:"2000000010021",cost:2200,price:8800,qty:5},
      {name:"New Balance 550",brand:"New Balance",category:"Sneakers",sku:"NS-003",barcode:"2000000010038",cost:3500,price:11000,qty:4},
      {name:"Detroit Jacket",brand:"Carhartt",category:"Jackets",sku:"NS-004",barcode:"2000000010045",cost:2800,price:13500,qty:2}
    ];

    for (const s of realSeeds) {
      const p = await db.query(
        `insert into products(store_id,name,brand,category,created_by)
         values($1,$2,$3,$4,$5) returning id`,
        [store.rows[0].id,s.name,s.brand,s.category,user.rows[0].id]
      );
      const v = await db.query(
        `insert into variants(store_id,product_id,sku,barcode,cost_cents,price_cents,low_stock_threshold)
         values($1,$2,$3,$4,$5,$6,1) returning id`,
        [store.rows[0].id,p.rows[0].id,s.sku,s.barcode,s.cost,s.price]
      );
      await db.query(
        `insert into inventory_balances(store_id,variant_id,quantity) values($1,$2,0)`,
        [store.rows[0].id,v.rows[0].id]
      );
      await appendInventoryEvent(db,{
        storeId:store.rows[0].id,
        variantId:v.rows[0].id,
        delta:s.qty,
        reason:"initial",
        actorUserId:user.rows[0].id
      });
    }
  }

  return { userId: user.rows[0].id, storeId: store.rows[0].id };
});

console.log("Seed complete");
console.log("login: owner@nightshift.local / Nightshift123!");
console.log("store id:", result.storeId);
await pool.end();
