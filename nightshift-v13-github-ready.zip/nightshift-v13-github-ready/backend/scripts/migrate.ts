import { readFile, readdir } from "node:fs/promises";
import { join } from "node:path";
import { pool } from "../src/db.js";

await pool.query(`
  create table if not exists schema_migrations (
    filename text primary key,
    applied_at timestamptz not null default now()
  )
`);

const dir = new URL("../migrations/", import.meta.url);
const names = (await readdir(dir)).filter(x => x.endsWith(".sql")).sort();

for (const filename of names) {
  const done = await pool.query(`select 1 from schema_migrations where filename=$1`, [filename]);
  if (done.rowCount) continue;

  const sql = await readFile(join(dir.pathname, filename), "utf8");
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    await client.query(sql);
    await client.query(`insert into schema_migrations(filename) values($1)`, [filename]);
    await client.query("COMMIT");
    console.log("applied", filename);
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}

await pool.end();
