# NIGHTSHIFT V13 — Garment Intelligence Core

Private vintage-clothing operating system and technology preview.

## Live preview
`index.html` is the interactive NIGHTSHIFT V13 technology preview.

## Backend
The complete TypeScript/Postgres/Redis/MinIO backend lives in `backend/`.

Core workflow:

`Intake → identity → barcode → material history → global comps → pricing → rack → scan → sale → learning`

## GitHub Pages
A Pages workflow is included at `.github/workflows/pages.yml`.
After pushing, enable **Settings → Pages → Source: GitHub Actions** once if GitHub has not enabled Pages automatically.

## Important
The preview simulates internet-wide comp research. The backend is structured to connect real search/comps providers; it does not fabricate live marketplace data.
